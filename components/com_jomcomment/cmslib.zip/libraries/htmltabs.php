<?php
(defined('_VALID_MOS') OR defined('_JEXEC')) or die('Direct Access to this location is not allowed.');

class CMSHtmltabs {

	
	function CMSHtmltabs(){
		
	}
}
