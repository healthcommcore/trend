<?php
define('WPRO_CENTRAL_SPELLCHECKER_URL', 'http://spellcheck.wysiwygpro.com/v2.0.0/');
?>