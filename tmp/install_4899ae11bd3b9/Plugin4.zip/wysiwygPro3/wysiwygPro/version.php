<?php

require_once('wysiwygPro.class.php');
$editor = new wysiwygpro();
echo $editor->productName.' '.$editor->version;

?>