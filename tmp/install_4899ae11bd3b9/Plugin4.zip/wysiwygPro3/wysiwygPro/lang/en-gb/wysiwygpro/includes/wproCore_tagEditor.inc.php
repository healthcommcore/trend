<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_tagEditor']=array();
$lang['wproCore_tagEditor']['title'] = 'Advanced Tag Editor';
$lang['wproCore_tagEditor']['General'] = 'General';
$lang['wproCore_tagEditor']['Appearance'] = 'Appearance';
$lang['wproCore_tagEditor']['CSS/Accessibility'] = 'CSS/Accessibility';
$lang['wproCore_tagEditor']['Language'] = 'Language';
$lang['wproCore_tagEditor']['content'] = 'Content';
$lang['wproCore_tagEditor']['viewDefinition'] = 'View the W3C definition for &lt;##tagName##&gt;';
$lang['wproCore_tagEditor']['tagInfo'] = '&lt;##tagName##&gt; tag info...';
?>