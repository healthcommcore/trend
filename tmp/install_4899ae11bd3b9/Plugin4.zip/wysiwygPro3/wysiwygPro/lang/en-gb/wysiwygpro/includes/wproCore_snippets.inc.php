<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_snippets'] = array();
$lang['wproCore_snippets']['pleaseSelect'] = 'Please select a snippet.';
?>