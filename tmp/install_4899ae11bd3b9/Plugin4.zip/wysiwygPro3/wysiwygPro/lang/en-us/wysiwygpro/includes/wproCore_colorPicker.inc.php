<?php 
if (!defined('IN_WPRO')) exit;
$lang=array();
$lang['wproCore_colorPicker'] = array();
$lang['wproCore_colorPicker']['title'] = 'Color Picker';
$lang['wproCore_colorPicker']['colorPalette'] = 'Color Palette:';
$lang['wproCore_colorPicker']['Web safe'] = '216 Web safe';
$lang['wproCore_colorPicker']['Site colors'] = 'Site colors';
?>