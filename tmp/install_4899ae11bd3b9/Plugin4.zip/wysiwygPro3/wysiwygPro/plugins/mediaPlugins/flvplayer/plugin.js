
/*
 * WysiwygPro 3.1.0.20080723 (c) Copyright Chris Bolt and ViziMetrics Inc. All Rights Reserved.
 * Unlicensed distribution, copying, reverse engineering, re-purposing or otherwise stealing of this code is a violation of copyright law.
 * Get yourself a license at www.wysiwygpro.com
 */

function wproFilePlugin_flvplayer () {
this.populateLocalOptions = function (data, prefix) {
var form = document.dialogForm;
if (data['width']) {
form.elements[prefix+'width'].value = data['width'];
form.elements[prefix+'widthUnits'].value = '';
} else {
form.elements[prefix+'width'].value = 320;
form.elements[prefix+'widthUnits'].value = '';
}
if (data['height']) {
form.elements[prefix+'height'].value = data['height'];
form.elements[prefix+'heightUnits'].value = '';
} else {
form.elements[prefix+'height'].value = 0;
form.elements[prefix+'heightUnits'].value = '';
}
if (form.elements[prefix+'playlist']) {
form.elements[prefix+'playlist'].checked = data['playlist'] ? true : false;
if (data['playlist']) {
this.updateWidth(prefix, true);
} else {
}
}
this.updateHeight(prefix);
}
this._getOptions = function (prefix, o) {
var form = document.dialogForm;
if (!o) o = {}
if (!o['object']) o['object'] = {};
if (!o['embed']) o['embed'] = {};
if (!o['param']) o['param'] = {};
if (form.elements[prefix+'width']) {
o['embed']['width'] = form.elements[prefix+'width'].value+form.elements[prefix+'widthUnits'].value;
o['object']['width'] = form.elements[prefix+'width'].value+form.elements[prefix+'widthUnits'].value;
}
if (form.elements[prefix+'height']) {
o['object']['height'] = form.elements[prefix+'height'].value+form.elements[prefix+'heightUnits'].value;
o['embed']['height'] = form.elements[prefix+'height'].value+form.elements[prefix+'heightUnits'].value;
}
return o;
}
this._fixRelative = function (url) {
var base = dialog.domain+dialog.URL+'media/';
url = url.replace(/^\//gi, dialog.domain+'/');
url = url.replace(/^([^#][^:"]*)$/gi, base+'$1');
while(url.match(/([^:][^\/])\/[^\/]*\/\.\.\//i)) {
url = url.replace(/([^:][^\/])\/[^\/]*\/\.\.\//i, '$1/');
}
url = url.replace(/\/\.\.\//gi, '/');
return dialog.urlFormatting(url);
}
this.insertLocal = function(prefix, data) {
if (!document.dialogForm.URL.value) return;
var form = document.dialogForm;
if (!data) data = {};
var o = this._getOptions(prefix, data);
var url = dialog.urlFormatting(dialog.domain+dialog.URL+'media/player.swf');
var file = form.URL.value;
var e = FB.getExtension(file);
if ((e=='.flv'||e=='.h264'||e=='.mp4') && dialog.urlFormat=='relative') {
file = dialog.urlFormatting(file, true);
var base = dialog.domain+dialog.URL+'media/';
var loc = dialog.domain;
if (loc.match(/^http(s|)\:\/\/www\./i)) {
var domainRegex = new RegExp('^'+( dialog.quoteMeta(loc).replace(/^(http(s|)\\\:\\\/\\\/)www\\\./i, '$1(www\\.|)') ) +'[^\/]*(|/)', 'gi');
} else {
var domainRegex = new RegExp('^'+( dialog.quoteMeta(loc).replace(/^(http(s|)\\\:\\\/\\\/)/i, '$1(www\\.|)') ) +'[^\/]*(|/)', 'gi');
}
file = file.replace(domainRegex, '$2');
var b = base.replace(domainRegex, '$2');
var r = new RegExp('^'+dialog.quoteMeta(b), 'gi');
file = file.replace(r, '');
if (file.substr(0,1)=='/') {
file = file.substr(1);
var c = b.match(/\//g);
for (var i=0;i<c.length;i++) {
file = '../'+file;
}
}
}
var flashvars = 'file=' + file +'&width='+form.elements[prefix+'width'].value+'&height='+form.elements[prefix+'height'].value;
if (flashvars.match(/.mp3/) ) {
flashvars += '&showeq=true';
}
if (form.elements[prefix+'autoplay']) {
flashvars += '&autostart='+(form.elements[prefix+'autoplay'].checked?'true':'false');
}
if (form.elements[prefix+'loop']) {
flashvars += '&repeat='+(form.elements[prefix+'loop'].checked?'true':'false');
}
if (form.elements[prefix+'controller']) {
flashvars += '&shownavigation='+(form.elements[prefix+'controller'].checked?'true':'false');
}
if (form.elements[prefix+'playlist']) {
if (form.elements[prefix+'playlist'].checked==true) {
flashvars += '&playlist=right&playlistsize='+form.elements[prefix+'playlistWidth'].value;
}
}
flashvars += '&fullscreen=true';
o['param']['movie'] = url;
o['param']['flashvars'] = flashvars;
o['param']['fullscreen'] = 'true';
o['embed']['src'] = url;
o['embed']['flashvars'] = flashvars;
o['embed']['fullscreen'] = 'true';
o['embed']['type'] = "application/x-shockwave-flash";
var s = '';
if (form.elements[prefix+'style']) {
s = form.elements[prefix+'style'].value
}
FB.insertMedia('flvplayer', o, s);
}
this.insertRemote = function (prefix) {
var data
if (FB.propertiesPlugin == 'flvplayer' && FB.mediaProperties) {
data = FB.mediaProperties;
}
this.insertLocal(prefix, data);
}
this.getPreviewURL = function (u) {
var url = dialog.domain+dialog.URL+'media/player.swf';
url += '?file=' + dialog.urlEncode(u)+'&autostart=true&fullscreen=true';
return url;
}
this.canPopulate = function () {
var arr = FB.getMediaProperties();
if (arr['param']) {
if (arr['param']['movie']) {
if (arr['param']['movie'].match('media/player.swf')) return true;
}
}
return false
}
this.updateHeight = function (prefix, show) {
var form = document.dialogForm;
if (/^[0-9]+$/.test(form.elements[prefix+'height'].value)) {
if (show||form.elements[prefix+'controller'].checked) {
var v = parseInt(form.elements[prefix+'height'].value) + parseInt(form.elements[prefix+'controllerHeight'].value)
form.elements[prefix+'height'].value = v;
} else {
var v = parseInt(form.elements[prefix+'height'].value) - parseInt(form.elements[prefix+'controllerHeight'].value)
form.elements[prefix+'height'].value = v;
}
}
}
this.updateWidth = function (prefix, show) {
var form = document.dialogForm;
if (/^[0-9]+$/.test(form.elements[prefix+'width'].value)) {
if (show||form.elements[prefix+'playlist'].checked) {
var v = parseInt(form.elements[prefix+'width'].value) + parseInt(form.elements[prefix+'playlistWidth'].value)
form.elements[prefix+'width'].value = v;
} else {
var v = parseInt(form.elements[prefix+'width'].value) - parseInt(form.elements[prefix+'playlistWidth'].value)
form.elements[prefix+'width'].value = v;
}
}
}
this.populateProperties = function (prefix) {
var form = document.dialogForm;
var o = FB.getMediaProperties();
if (form.elements[prefix+'width']&&o['object']['width']) {
form.elements[prefix+'width'].value = String(o['object']['width']).replace(/[^0-9]/g, '');
if (String(o['object']['width']).match('%')) {
form.elements[prefix+'widthUnits'].value = '%';
} else {
form.elements[prefix+'widthUnits'].value = '';
}
}
if (form.elements[prefix+'height']&&o['object']['height']) {
form.elements[prefix+'height'].value = String(o['object']['height']).replace(/[^0-9]/g, '');
if (String(o['object']['height']).match('%')) {
form.elements[prefix+'heightUnits'].value = '%';
} else {
form.elements[prefix+'heightUnits'].value = '';
}
}
if (o['param']['flashvars']) {
if (form.elements[prefix+'autoplay']) {
if (o['param']['flashvars'].match(/[?&]autostart=true/gi)) {
form.elements[prefix+'autoplay'].checked = true;
} else {
form.elements[prefix+'autoplay'].checked = false;
}
}
if (form.elements[prefix+'loop']) {
if (o['param']['flashvars'].match(/[?&]repeat=true/gi)) {
form.elements[prefix+'loop'].checked = true;
} else {
form.elements[prefix+'loop'].checked = false;
}
}
if (form.elements[prefix+'controller']) {
if (o['param']['flashvars'].match(/[?&]shownavigation=true/gi)) {
form.elements[prefix+'controller'].checked = true;
} else {
form.elements[prefix+'controller'].checked = false;
}
}
if (form.elements[prefix+'playlist']) {
if (o['param']['flashvars'].match(/[?&]playlist=/gi)) {
form.elements[prefix+'playlist'].checked = true;
} else {
form.elements[prefix+'playlist'].checked = false;
}
}
var m = o['param']['flashvars'].match(/([?&]|^)file=([^&]+)/gi);
if (m) {
var file = m[0].replace(/[?&]*file=/gi, '');
var e = FB.getExtension(file);
if ((e=='.flv'||e=='.h264'||e=='.mp4') && dialog.urlFormat=='relative') {
file = this._fixRelative(file);
}
form.URL.value = dialog.urlFormatting(file);
}
}
}
}