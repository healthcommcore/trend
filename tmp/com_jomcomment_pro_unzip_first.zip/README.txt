===============================
Package contents
===============================

- com_jomcomment_pro_Joomla-1.0.x.tar.gz
	Installer file for main Jom Comment component, for Joomla 1.0.x series
	
- com_jomcomment_pro_Joomla-1.5.x.tar.gz
	Installer file for main Jom Comment component, for Joomla 1.5.1 series


===============================
Pre-Installation Checklist
===============================

1. Make sure the following folder is writeable. If you have a previous

/administrator/components/
/components/
/mambots/content/	(Joomla 1.0)
/mambots/system/	(Joomla 1.0)
/plugins/content/	(Joomla 1.5)
/plugins/system/	(Joomla 1.5)

===============================
Obtaining Support
===============================

1. Support forum.
Please visit http://forum.azrul.com . This is perhaps the fastest way for you to find a solution to your problem. The forum should help fix 90% of user issues.

2. Support ticket.
Login to your account at http://support.azrul.com and send us a ticket from there.

3. Email
You can also write to us at support@azrul.com   
