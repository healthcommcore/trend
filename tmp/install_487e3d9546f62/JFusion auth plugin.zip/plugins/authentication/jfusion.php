<?php
// $Id$
// no direct access
defined('_JEXEC' ) or die('Restricted access' );
// Import library dependencies
jimport('joomla.event.plugin');
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');

class plgAuthenticationjfusion extends JPlugin
{
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for
     * plugins because func_get_args ( void ) returns a copy of all passed arguments
     * NOT references.  This causes problems with cross-referencing necessary for the
     * observer design pattern.
     */
    function plgAuthenticationjfusion(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }
    
    /**
     * This method should handle any authentication and report back to the subject
     *
     * @access	public
     * @param   array 	$credentials Array holding the user credentials
     * @param 	array   $options     Array of extra options
     * @param	object	$response	 Authentication response object
     * @return	boolean
     * @since 1.5
     */
    function onAuthenticate($credentials, $options, &$response )
    {
        jimport('joomla.user.helper');
        // Joomla does not like blank passwords
        if (empty($credentials['password'])) {
            $response->status = JAUTHENTICATE_STATUS_FAILURE;
            $response->error_message = 'Empty password not allowed';
            return false;
        }
        // Initialize variables
        $conditions = '';
        $db =& JFactory::getDBO();

        //check to see if a JFusion plugin is enabled
        $jname = AbstractForum::getJname();
        if ($jname) {
            //get main params
            $params = AbstractForum::getMainSettings();
            if (!$params->get('mirror_users')) {
                //If find out if the user has a special Joomla usergroup
                $query = "SELECT usertype FROM #__users WHERE `username`='".$credentials['username']."'";
                $db->setQuery($query);
                $usertype = $db->loadResult();
            } else {
                $usertype = false;
            }
            if ($usertype != 'Registered' && $usertype) {
                //use the joomla default so people can not lock Joomla itself
                // Get a database object
                $db =& JFactory::getDBO();
                $query = 'SELECT `id`, `password`, `gid` FROM `#__users`
                    WHERE username=' . $db->Quote($credentials['username'] );
                $db->setQuery($query );
                $result = $db->loadObject();
                // if JFusion disabled & user found OR user found & has access to backend = tries to login
                $parts = explode(':', $result->password );
                $crypt = $parts[0];
                $salt = @$parts[1];
                $testcrypt = JUserHelper::getCryptedPassword($credentials['password'], $salt);
            } else {
                //initialize the forum object
                $forum = ForumFactory::getForum($jname);
                //Get the stored encrypted password
                $username = $forum->filterUsername($credentials['username']);
                $userinfo = $forum->getUser($username);
                // baltie - fixed a bug; now checks if $userinfo is set, if it is,
                // generate as before, if not, set $crypt to 0, as this will trigger
                // an authentication failure, and not a script failure
                if ($userinfo) {
                    $crypt = $userinfo->password;
                    //apply the cleartext password to the user object
                    $userinfo->password_clear = $credentials['password'];
                    
                    //created new authentication class that can handle different password encryptions
                    //without adding much overhead in terms of performance
                    require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.auth_factory.php');

                    //find out which encryption methods we need to try out
                    // baltie - name, not jname
                    $query = "SELECT name FROM #__jfusion WHERE enabled = 1 OR check_encryption = 1 ORDER BY enabled DESC";
                    $db->setQuery($query);
                    $auth_models = $db->loadObjectList();
                    foreach ($auth_models as $auth_model) {
                        //Generate an encrypted password for comparison
                        $model = AuthFactory::getAuth($auth_model->name);
                        $testcrypt = $model->generateEncryptedPassword($userinfo);
                        if ($crypt == $testcrypt) {
                            //found a match
                            $response->status = JAUTHENTICATE_STATUS_SUCCESS;
                            $response->error_message = '';
                            return true;
                        }
                    }
                } else {
                    $crypt = 0;
                }
            }
        } else {
            //use the joomla default so people can not lock Joomla itself
            // Get a database object
            $db =& JFactory::getDBO();
            $query = 'SELECT `id`, `password`, `gid` FROM `#__users`
                WHERE username=' . $db->Quote($credentials['username']);
            $db->setQuery($query );
            $result = $db->loadObject();
            // if JFusion disabled & user found OR user found & has access to backend = tries to login
            $parts = explode(':', $result->password );
            $crypt = $parts[0];
            $salt = @$parts[1];
            $testcrypt = JUserHelper::getCryptedPassword($credentials['password'], $salt);
        }
        // login action
        if ($crypt) {
            if ($crypt == $testcrypt) {
                $response->status = JAUTHENTICATE_STATUS_SUCCESS;
                $response->error_message = '';
            } else {
                $response->status = JAUTHENTICATE_STATUS_FAILURE;
                $response->error_message = 'Invalid password';
            }
        } else {
            $response->status = JAUTHENTICATE_STATUS_FAILURE;
            $response->error_message = 'User does not exist';
        }
    }
}
