DROP TABLE #__jfusion;
DROP TABLE #__jfusion_user_lookup;