<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');

class JElementForum extends JElement
{
    var $_name = "Forum";

    function fetchElement($name, $value, &$node, $control_name)
    {
        $jname = AbstractForum::getJname();
        $forum = ForumFactory::getForum($jname);
        $forumlist = $forum->getForumList();
        
        if (!empty($forumlist))
            return JHTML::_('select.genericlist', $forumlist, $control_name.'['.$name.'][]', 'multiple size="6" class="inputbox"',
                'id', 'name', $value);
        else
            return '';
    }
}
?>