<?php

function login_checker()  {

    $credentials['username'] = JRequest::getVar('check_username', '', 'POST', 'STRING' );
    $user['username'] = JRequest::getVar('check_username', '', 'POST', 'STRING' );
    $credentials['password'] = JRequest::getVar('check_password', '', 'POST', 'STRING' );
    $options['group'] =JRequest::getVar('check_group', '', 'POST', 'STRING' );


    echo '- Performing the JFusion Authentication function for user:' . $credentials['username'] .'<br>';

    jimport('joomla.user.helper');
    // Joomla does not like blank passwords
    if (empty($credentials['password'])) {
        echo 'No password was supplied';
        return;
    }

    if (empty($credentials['username'])) {
        echo 'No username was supplied';
        return;
    }

    // Initialize variables
    $conditions = '';
    $db = & JFactory::getDBO();

    //check to see if a JFusion plugin is enabled
    $jname = AbstractForum::getJname();
    if ($jname) {
        echo '- JFusion is enabled<br>';
        //get main params
        $params = AbstractForum::getMainSettings();
        if (!$params->get('mirror_users')) {
            echo '- Special users are in the Joomla database, check for these first<br>';
            //If find out if the user has a special Joomla usergroup
            $query = "SELECT usertype FROM #__users WHERE `username`='".$credentials['username']."'";
            $db->setQuery($query);
            $usertype = $db->loadResult();
        } else {
            $usertype = false;
        }
        if ($usertype != 'Registered' && $usertype) {
            //use the joomla default so people can not lock Joomla itself
            echo '- found a Joomla special user and will lookup the Joomla password<br>';
            // Get a database object
            $db =& JFactory::getDBO();
            $query = 'SELECT `id`, `password`, `gid`'
            . ' FROM `#__users`'
            . ' WHERE username=' . $db->Quote($credentials['username'] );
            $db->setQuery($query );
            $result = $db->loadObject();
            // if JFusion disabled & user found OR user found & has access to backend = tries to login
            $parts = explode(':', $result->password );
            $crypt = $parts[0];
            $salt = @$parts[1];
            $testcrypt = JUserHelper::getCryptedPassword($credentials['password'], $salt);
        } else {
            echo '- using the forum database to check the users password<br>';
            
            
            
                //initialize the forum object
                $forum = ForumFactory::getForum($jname);
                //Get the stored encrypted password
                $username = $forum->filterUsername($credentials['username']);
                echo "- the forum filtered username is: $username <br>";

                $userinfo = $forum->getUser($username);
                echo '- the userinfo object contains the array:' . print_r($userinfo) . '<br>';
                
                // baltie - fixed a bug; now checks if $userinfo is set, if it is,
                // generate as before, if not, set $crypt to 0, as this will trigger
                // an authentication failure, and not a script failure
                if ($userinfo) {
                    echo 'found the user in the forum database<br>';
                    $crypt = $userinfo->password;
                    //apply the cleartext password to the user object
                    $userinfo->password_clear = $credentials['password'];

                    //created new authentication class that can handle different password encryptions
                    //without adding much overhead in terms of performance
                    require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.auth_factory.php');

                    //find out which encryption methods we need to try out
                    // baltie - name, not jname
                    $query = "SELECT name FROM #__jfusion WHERE enabled = 1 OR check_encryption = 1 ORDER BY enabled DESC";
                    $db->setQuery($query);
                    $auth_models = $db->loadObjectList();

                    echo '- starting to loop through the different password encryption methods<br>';
                    foreach ($auth_models as $auth_model) {
                        //Generate an encrypted password for comparison
                        $model = AuthFactory::getAuth($auth_model->name);
                        $testcrypt = $model->generateEncryptedPassword($userinfo);
                        echo "- database password: $crypt  and $auth_model->name password: $testcrypt <br>";
                        if ($crypt == $testcrypt) {
                            //found a match
                            echo '- found a matching password <br>';
                        }
                    }
                } else {
                    echo '- Sorry did not find this user in the database, block access.<br>';
                    return;
                }
            
            
        }
    } else {
        echo '- JFusion is NOT enabled, using the Joomla default login<br>';
        //use the joomla default so people can not lock Joomla itself
        // Get a database object
        $db =& JFactory::getDBO();
        $query = 'SELECT `id`, `password`, `gid`'
        . ' FROM `#__users`'
        . ' WHERE username=' . $db->Quote($credentials['username'] );
        $db->setQuery($query );
        $result = $db->loadObject();
        // if JFusion disabled & user found OR user found & has access to backend = tries to login
        $parts = explode(':', $result->password );
        $crypt = $parts[0];
        $salt = @$parts[1];
        $testcrypt = JUserHelper::getCryptedPassword($credentials['password'], $salt);

    // login action
    echo "- the password hash in the database is: $crypt <br>";
    echo "- the password hash generated from the cleartext password is: $testcrypt <br>";

    if ($crypt) {
        if ($crypt == $testcrypt) {
            echo '- the passwords do match<br>';
        } else {
            echo '- the passwords do NOT match<br>';
            return;             }
    } else {
        echo '- the user was not found in the database<br>';
        return;
    }
    }

    jimport('joomla.user.helper');

    echo '<br><br>- Performing the JFusion User function<br>';

    //initalise the Joomla database object
    $db =& JFactory::getDBO();

    //get main params
    $params = AbstractForum::getMainSettings();

    // Get an ACL object
    $acl =& JFactory::getACL();

    /*
     * First create the JUser object
     */


    //check to see if a JFusion plugin is enabled
    $jname = AbstractForum::getJname();
    if ($jname) {
    echo '- JFusion integration enabled <br>';

     //If find out if the user has already exists in the Joomla database
            $userLookup = AbstractForum::lookupUsername($jname, $user['username']);
            if ($userLookup) {
                $userid = $userLookup->juser_id;
                echo '- found a user in the lookup table the info:' . print_r($userLoopkup) . '<br>';
            } else {
                echo '- no entry found in the lookup table, checking in the Joomls user table directly <br>';
                $query = "SELECT id FROM #__users WHERE username='".$user['username']."'";
	            $db->setQuery($query);
	            $userid = $db->loadResult();
            }

        if ($userid) {
            echo "- the user already exist in the Joomla database with userid: $userid <br>";
            //no need to create a new user object, just use the one stored.
            $instance =& JUser::getInstance($userid);
            //use the usergroup from the Joomla user table
            $grp = $acl->getAroGroup($instance->get('id'));


        } else {
            echo "- the user does NOT exist in the Joomla database <br>";
            //find out if we should create a permanent entry in the Joomla database
            if ($params->get('mirror_users')) {
                echo "- auto user mirroring is turned on, therefore we will create a new Joomla user <br>";
                //yes we should create one
                $forum = ForumFactory::getForum($jname);
                $instance = & $forum->getUser($user,$options);
                $usertype = $params->get('joomla_usergroup');
                $query = "SELECT id FROM #__core_acl_aro_groups WHERE name = '" . $usertype . "'";
                $db->setQuery($query);
                $gid = $db->loadResult();
                AbstractForum::createJoomlaUsername($username, $instance->get('email'), $instance->get('password'), $usertype, $gid);

                //load the user object for the newly created uer
                $query = "SELECT id FROM #__users WHERE username='".$username ."'";
                $db->setQuery($query);
                $userid = $db->loadResult();
                echo "- the userid for the newly created Joomla user is: $userid <br>";
                $instance =& JUser::getInstance($userid);
                $grp = $acl->getAroGroup($instance->get('id'));
            } else {
                //no just setup a user object but do not save it
                echo "- auto user mirroring is turned off, therefore we will create a temporary Joomla user <br>";
                $forum = ForumFactory::getForum($jname);
                $instance = & $forum->getUser($user,$options);

                $usertype = $params->get('joomla_usergroup');
                $query = "SELECT id FROM #__core_acl_aro_groups WHERE name = '" . $usertype . "'";
                $db->setQuery($query);
                $gid = $db->loadResult();
                $instance->set('gid',$gid);
                $instance->set('usertype' , $usertype );
                $instance->set('username', $username);
                $grp = new JObject;
                $grp->set('name', 'Registered');
            }
        }
    } else {
        echo "- No JFusion integration is enabled, using the Joomla default <br>";
        return;
    }

    // If the user is blocked, redirect with an error
    if ($instance->get('block') == 1  ) {
        echo '- this user is blocked from accessing Joomla with the blocked setting';
    }

    echo "-The Joomla usergroup for this user is: $grp->name <br>";
}


?>

