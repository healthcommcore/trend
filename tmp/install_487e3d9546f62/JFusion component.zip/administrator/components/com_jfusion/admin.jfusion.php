<?php
/**
 * @package com_jfusion
 * @version 1.0.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */


// no direct access
defined('_JEXEC' ) or die('Restricted access' );

//load the php code needed for JFusion to run
require_once(JApplicationHelper::getPath('admin_html' ) );
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');

switch ($task) {
    case 'show_install':
        show_install();
        break;
    case 'main_config':
        main_config();
        break;
    case 'publish':
        publish();
        break;
    case 'unpublish':
        unpublish();
        break;
    case 'disable_encryption':
        disable_encryption();
        break;
    case 'enable_encryption':
        enable_encryption();
        break;
    case 'config':
        show_config();
        break;
    case 'sync':
        show_sync();
        break;
    case 'apply_sync':
        apply_sync();
        break;
    case 'synclist':
        synclist();
        break;
    case 'save':
        save_config();
        break;
    case 'save_main':
        save_main();
        break;
    case 'apply':
        save_config();
        break;
    case 'wizard':
        show_wizard();
        break;
    case 'help':
        jfusionScreens::jfusionhelp();
        break;
    case 'wizard_save':
        wizard_save();
        break;
        /* plugin manipulation */
    case 'add_plugin':
        add_plugin();
        break;
    case 'install_plugin':
        install_plugin();
        break;
    case 'remove_plugin':
        uninstall_plugin();
        break;
 case 'ajax_sync':
     ajax_sync();
     break;
 case 'ajax_sync_status':
     ajax_sync_status();
     break;
 case 'check_login':
     check_login();
     break;
 case 'check_login_form':
  check_login_form();
     break;
     case 'test_username';
     test_username();
     break;
    default:
        show_install();
        break;
}

function show_install()
{
    //get a list of supported software types
    $db = & JFactory::getDBO();
    $query = 'SELECT * from #__jfusion';
    $db->setQuery($query );
    $rows = $db->loadObjectList();

    if($rows) {

        //check for plugin installation
        AbstractForum::checkPlugin();

        //print out results to user
        jfusionScreens::startForm();
        jfusionScreens::showInstall( $rows);
        jfusionScreens::endForm();
    } else {
        JError::raiseWarning(500, JText::_('NO_JFUSION_TABLE'));
    }
}

function main_config()
{
    //get the main JFusion parameters
    $params = AbstractForum::getMainSettings();

    //check for plugin installation
    AbstractForum::checkPlugin();

    jfusionScreens::startForm();
    jfusionScreens::mainConfig($params->render());
    jfusionScreens::endForm();
}

function publish()
{
    //find out the posted ID of the JFusion module to publish
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING' );

    //check to see if an integration was selected
    if ($jname) {

        //get a Joomla Database connection
        $db = & JFactory::getDBO();

        //First unpublish all other JFusion modules, as only single integrations are supported for now.
        $query = 'UPDATE #__jfusion SET enabled=0';
        $db->setQuery($query );
        $db->query();

        //Then publish the JFusion module as requested
        $query = 'UPDATE #__jfusion SET enabled=1 WHERE name = ' . "'$jname'";
        $db->setQuery($query );
        $db->query();
    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
    }

    //render configuration overview
    show_install();
}

function unpublish()
{
    //find out the posted ID of the JFusion module to unpublish
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING');

    //check to see if an integration was selected
    if ($jname) {
        //get a Joomla Database connection
        $db = & JFactory::getDBO();

        //Then unpublish the JFusion module as requested
        $query = 'UPDATE #__jfusion SET enabled=0 WHERE name = ' . "'$jname'";
        $db->setQuery($query );
        $db->query();
    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
    }

    //render configuration overview
    show_install();
}

function disable_encryption() {

  //find out the posted ID of the JFusion module to unpublish
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING');

    //check to see if an integration was selected
    if ($jname) {
        //get a Joomla Database connection
        $db = & JFactory::getDBO();

        //Then unpublish the JFusion module as requested
        $query = 'UPDATE #__jfusion SET check_encryption=0 WHERE name = ' . "'$jname'";
        $db->setQuery($query );
        $db->query();
    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
    }

    //render configuration overview
    show_install();

}

function enable_encryption() {

  //find out the posted ID of the JFusion module to unpublish
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING');

    //check to see if an integration was selected
    if ($jname) {
        //get a Joomla Database connection
        $db = & JFactory::getDBO();

        //Then unpublish the JFusion module as requested
        $query = 'UPDATE #__jfusion SET check_encryption=1 WHERE name = ' . "'$jname'";
        $db->setQuery($query );
        $db->query();
    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
    }

    //render configuration overview
    show_install();

}

function save_config()
{
    //get the params posted to the component
    $post = JRequest::getVar('params', array(), 'post', 'array' );


    //check for trailing slash in URL, in order for us not to worry about it later
    if (substr($post['source_url'], -1) == '/') {
    } else {
        $post['source_url'] .= '/';
    }

    //now also check to see that the url starts with http://
    if (substr($post['source_url'], 0, 7) == 'http://') {
    } else {
        $post['source_url'] = 'http://' . $post['source_url'];
    }

    //get the submitted name for the JFusion module
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING' );

    if (AbstractForum::saveParameters($jname, $post)) {
        JError::raiseNotice(0, JText::_('SAVE_SUCCESS'));
    } else {
        JError::raiseWarning(500, JText::_('SAVE_FAILURE'));
    }
    if($task == 'apply') {
        show_config();
    } else {
        show_install();
    }
}
function show_config()
{
    //find out the submitted name of the JFusion module
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING');

    if ($jname) {
        //show the config
        //Get the parameters for the JFusion module
        $params = AbstractForum::getSettings($jname);

        //do a check on the current configuration
        //$forum->validateCongfiguration();

        //render all parameters specific to the forum type
        jfusionScreens::startForm();
        jfusionScreens::jfusionconfig($jname, $params->render());
        jfusionScreens::endForm();

    } else {
        //show main screen
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
        show_install();

    }
}

/**
 * Save the results of the wizard set-up
 *
 */
function wizard_save()
{
    // get the posted path
    $post = JRequest::getVar('params', array(), 'post', 'array' );

    //find out the submitted name of the JFusion module
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING' );

    //check to see if a integration was selected
    if ($jname) {
        //Initialize the forum
        $forum = ForumFactory::getForum($jname);
        $params = $forum->setupFromPath($post['source_path'], $jname);

        //check to see if wizard was succesful
        if($params) {
            //output found data to user
            jfusionScreens::startForm();
            jfusionScreens::jfusionwizard_config($jname, $params->render());
            jfusionScreens::endForm();
        } else {
            //output default config screen to user
            $params = AbstractForum::getSettings($jname);
            jfusionScreens::startForm();
            jfusionScreens::jfusionconfig($jname, $params->render());
            jfusionScreens::endForm();
        }



    } else {
        show_install();
    }
}
/**
 * Save the results of the wizard set-up
 *
 */

function show_wizard()
{
    //find out the submitted name of the JFusion module
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING' );

    //check to see if a integration was selected
    if ($jname) {
        jfusionScreens::startForm();
        jfusionScreens::jfusionwizard($jname);
        jfusionScreens::endForm();
    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
        show_install();
    }

}
/**
 * Function that compares users between integrations. Not in use at the moment.
 *
 */

function show_sync()
{
    //find out the posted ID of the JFusion module to publish
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING' );


    //check to see if an integration was selected
    if ($jname) {

        //check to see if the integation database is working correctly
        $db = & JFactory::getDBO();
        $query = "SELECT status from #__jfusion WHERE name = '" . $jname . "'";
        $db->setQuery($query );
        $status = $db->loadResult();
        if($status == 3) {

            //print out results to user
            jfusionScreens::startForm();
            jfusionScreens::jfusionsync($jname);
            jfusionScreens::endForm();

        } else {
            JError::raiseWarning(500, JText::_('SYNC_NOCONFIG'));
        }

    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
    }

}

function syncarray($jname)
{

    $jusers = AbstractForum::getJoomlaUsers();
    $forum = ForumFactory::getForum($jname);
    $fusers = $forum->getForumUsers();

    //we need to include array_functions for the people that do not have php5
    require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/array_functions.php');

    //find out which use match, so we don't have to worry about them
    $matched_users = array_intersect_assoc($jusers, $fusers);

    //remove the matched users from the arrays
    $joomla_todo = array_diff_assoc($jusers, $matched_users);
    $forum_todo = array_diff_assoc($fusers, $matched_users);

    //find out the discrepancies
    $syncarray = array ( 0 => $matched_users,
    3 => $forum_todo,
    4 => $joomla_todo,
    5 => $jusers,
    6 => $fusers);
    return $syncarray;

}


function apply_sync()
{
    //get the posted options
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING' );
    $email_conflict = JRequest::getVar('email_conflict', '', 'POST', 'STRING' );

    //get the sync array
    $syncarray = syncarray($jname);

    
    //we need to make sure that the jfusion_user_lookup table is up2date for the matched users
    //otherwise JFusion will not work for the people who upgrade to the latest version
    // and have previously done a usersync through JKusion.
    echo '<br><h2>' . JText::_('SYNC_UPDATING_TABLE') . '</h2><br><br><br>';
    AbstractForum::updateLookup($jname, $syncarray[0]);
    
    

    echo '<br><h2>' . JText::_('SYNC_INTEGRATION') . '</h2><br><br><br>';


        //get the database ready
        $db = & JFactory::getDBO();
        //we need to find the group ID to setup Joomla permissions
        $params = AbstractForum::getMainSettings();
        $usertype = $params->get('joomla_usergroup');
        $query = "SELECT id FROM #__core_acl_aro_groups WHERE name = '" . $usertype . "'";
        $db->setQuery($query);
        $gid = $db->loadResult();

        //initialise the forum object for getting passwords
        $forum = ForumFactory::getForum($jname);


        foreach ($syncarray[3] as $key => $value) {
            if ($value) {
                $plugin_user = $forum->getUser($key);

                AbstractForum::createJoomlaUsername($jname, $plugin_user->userid, $plugin_user->username, $value, $plugin_user->password, $usertype, $gid, $params, $email_conflict );
                echo JText::_('CREATE_USER') . $key . '<br>';
                $credentials = '';
                $password = '';
            }
        }
    }



function save_main()
{
    $post['params'] = JRequest::getVar('params', array(), 'post', 'array' );

    if (AbstractForum::saveMainParameters($post)) {
        JError::raiseNotice(0, JText::_('SAVE_SUCCESS'));
    } else {
        JError::raiseWarning(500, JText::_('SAVE_FAILURE'));
    }
    main_config();
}

/*
 * plugin installation functions
 */
/**
 * display installation screen
 * @return
 */
function add_plugin() {

    //$bar =& new JToolBar('Add plugin' );
    //$bar->appendButton('Standard', 'save', JText::_('INSTALL'), 'install_plugin', false, false );
    //echo $bar->render();

    jfusionScreens::add_plugin();

}
/**
 * upload, parse & install plugins
 * @return
 */
function install_plugin() {
    require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/install.php');
    $model = new JfusionModelInstaller();

    $model->install();

    show_install();

}

function uninstall_plugin() {
    $jname = JRequest::getVar('jname', '', 'POST', 'STRING', _J_ALLOWHTML );

    //check to see if an integration was selected
    if ($jname) {
        require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/install.php');
        $model = new JfusionModelInstaller();
        $model->uninstall($jname);

    } else {
        JError::raiseWarning(500, JText::_('NONE_SELECTED'));
    }

    show_install();
}

function ajax_sync_status() {

die('ajax is working');


}

function ajax_sync() {

//generate a user sync sessionid
$syncid = AbstractForum::createPassword( 10 );

//add it to the usersync table so that the usersync is ready to start
$db = & JFactory::getDBO();
$query = "INSERT INTO #__jfusion_sync (syncid) VALUES ('" . $syncid ."');";
$db->setQuery($query );
$db->query();

//output the syncform
jfusionScreens::ajax_sync($syncid);


}

function check_login() {

require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.login_checker.php');
login_checker();

}


function check_login_form() {
    jfusionScreens::startForm();
    jfusionScreens::check_login_form();
    jfusionScreens::endForm();
}



?>
