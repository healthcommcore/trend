<?php
/**
* @package com_jfusion
* @version 1.0.5
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

/** ensure this file is being included by a parent file */
defined('_JEXEC' ) or die('Restricted access' );


class jfusionWrap {
function show_url($url)
{

    $params = AbstractForum::getMainSettings();
    
    

echo "
<script language=\"javascript\" type=\"text/javascript\">
function iFrameHeight() {
var h = 0;
if ( !document.all ) {
h = document.getElementById('blockrandom').contentDocument.height;
document.getElementById('blockrandom').style.height = h + 60 + 'px';
} else if( document.all ) {
h = document.frames('blockrandom').document.body.scrollHeight;
document.all.blockrandom.style.height = h + 20 + 'px';
}
}
</script>
<div class=\"contentpane\">
<iframe  ";

if($params->get('wrapper_autoheight')) {
echo "onload=\"iFrameHeight()\"";
}


echo " id=\"blockrandom\"
name=\"iframe\"
src=\"" . $url . "\"
width=\"" . $params->get('wrapper_width') ."\"
height=\"" . $params->get('wrapper_height') ."\"
scrolling=\"" . $params->get('wrapper_scroll') ."\"
allowtransparency=\"";

if ($params->get('wrapper_transparency')) {
echo 'true';
} else {
echo 'false';
}
echo "\"
align=\"top\"
frameborder=\"0\"
class=\"wrapper\">
This option will not work correctly.
Unfortunately, your browser does not support Inline Frames
</iframe>
</div>
<div class=\"back_button\">
<a href='javascript:history.go(-1)'>
[ Back ]</a>
</div>
";
}
}
?>

