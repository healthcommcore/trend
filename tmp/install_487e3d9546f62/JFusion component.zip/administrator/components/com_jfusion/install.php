<?php
/**
 * 
 * JFusion plugin manager
 * @package jfusion
 * @author Matheus Mendes
 * @version $Id$ 
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

require_once(JPATH_ADMINISTRATOR .'/components/com_installer/models/install.php');

/**
 * Class to manage plugins in JFusion 
 */
class JfusionModelInstaller extends InstallerModelInstall {
	
	/** @var object JTable object */
	var $_table = null;

	/** @var object JTable object */
	var $_url = null;

	/**
	 * Overridden constructor
	 * @access	protected
	 */
	function __construct()
	{
		parent::__construct();

	}

	/**
	 * Replaces original Install() method.
	 * @return 
	 */
	function install() {
		global $mainframe;

		$this->setState('action', 'install');

		switch(JRequest::getWord('installtype'))
		{
			case 'folder':
				$package = $this->_getPackageFromFolder();
				break;

			case 'upload':
				$package = $this->_getPackageFromUpload();
				break;

			case 'url':
				$package = $this->_getPackageFromUrl();
				break;

			default:
				$this->setState('message', 'No Install Type Found');
				return false;
				break;
		}
		
		// Was the package unpacked?
		if (!$package) {
			$this->setState('message', 'Unable to find install package');
			return false;
		}
		
		// custom installer
		$installer = new JinstallerJfusionPlugins($this);
		// Install the package
		if (!$installer->install($package['dir'])) {
			// There was an error installing the package
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Error'));
			$result = false;
		} else {
			// Package installed sucessfully
			$msg = JText::sprintf('INSTALLEXT', JText::_($package['type']), JText::_('Success'));
			$result = true;
		}
		// Set some model state values
		$mainframe->enqueueMessage($msg);
		$this->setState('name', $installer->get('name'));
		$this->setState('result', $result);
		$this->setState('message', $installer->message);
		$this->setState('extension.message', $installer->get('extension.message'));

		// Cleanup the install files
		if (!is_file($package['packagefile'])) {
			$config =& JFactory::getConfig();
			$package['packagefile'] = $config->getValue('config.tmp_path').DS.$package['packagefile'];
		}

		JInstallerHelper::cleanupInstall($package['packagefile'], $package['extractdir']);

		return $result;


	}
	
	function uninstall($jname) {
		$db =& JFactory::getDBO();
		$db->setQuery("SELECT id FROM #__jfusion WHERE jname =". $db->Quote($jname));
		$myId = $db->loadResult();
		if (!$myId) {
			;// error!! plugin not installed (hack attempt?)
		}
		
		$installer = new JinstallerJfusionPlugins($this);
		// Install the package
		if (!$installer->uninstall($jname)) {
			// There was an error installing the package
			$msg = JText::sprintf('UNINSTALLEXT', JText::_($package['type']), JText::_('Error'));
			$result = false;
		} else {
			// Package installed sucessfully
			$msg = JText::sprintf('UNINSTALLEXT', JText::_($package['type']), JText::_('Success'));
			$result = true;
		}
		
		return $result;
		
	}
}

/**
 * Installer class for JFusion plugins
 */
class JinstallerJfusionPlugins extends JObject {
	
	function __construct(&$parent) {
		
		$this->parent =& JInstaller::getInstance();
		$this->parent->setOverwrite(true);
	}
	
	/**
	 * handles installation
	 * @return boolean
	 */
	function install($dir=null) {
		// Get a database connector object
		$db =& JFactory::getDBO();
		
		if ($dir && JFolder::exists($dir)) {
			$this->parent->setPath('source', $dir);

		} else {
			$this->parent->abort(JText::_('Install path does not exist'));
			return false;
		}
		
		// Get the extension manifest object
		$manifest = $this->_getManifest($dir);
		$this->manifest =& $manifest->document;
		//var_dump($this->manifest);
		
		/**
		 * ---------------------------------------------------------------------------------------------
		 * Manifest Document Setup Section
		 * ---------------------------------------------------------------------------------------------
		 */

		// Set the extensions name
		$name =& $this->manifest->getElementByPath('name');
		$name = JFilterInput::clean($name->data(), 'string');
		$this->set('name', $name);
		

		// Get the component description
		$description = & $this->manifest->getElementByPath('description');
		if (is_a($description, 'JSimpleXMLElement')) {
			$this->parent->set('message', $description->data());
		} else {
			$this->parent->set('message', '' );
		}
		$myDesc = JFilterInput::clean($description->data(), 'string');
		
		// installation path
		$this->parent->setPath('extension_root', JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jfusion'.DS.'plugins'.DS. $name);
		
		// get files to copy
		$element =& $this->manifest->getElementByPath('files');
		if (is_a($element, 'JSimpleXMLElement') && count($element->children())) {
			$files =& $element->children();
			foreach ($files as $file) {
				if ($file->attributes($type)) {
					$pname = $file->attributes($type);
					break;
				}
			}
		}

		/**
		 * ---------------------------------------------------------------------------------------------
		 * Filesystem Processing Section
		 * ---------------------------------------------------------------------------------------------
		 */
		// If the plugin directory does not exist, lets create it
		$created = false;
		if (!file_exists($this->parent->getPath('extension_root'))) {
			if (!$created = JFolder::create($this->parent->getPath('extension_root'))) {
				$this->parent->abort(JText::_('Plugin').' '.JText::_('Install').': '.JText::_('Failed to create directory').': "'.$this->parent->getPath('extension_root').'"');
				return false;
			}
		}
		
		/*
		 * If we created the plugin directory and will want to remove it if we
		 * have to roll back the installation, lets add it to the installation
		 * step stack
		 */
		if ($created) {
			$this->parent->pushStep(array ('type' => 'folder', 'path' => $this->parent->getPath('extension_root')));
		}

		// Copy all necessary files
		if ($this->parent->parseFiles($element, -1) === false) {
			// Install failed, roll back changes
			$this->parent->abort();
			return false;
		}
		
		/**
		 * ---------------------------------------------------------------------------------------------
		 * Database Processing Section
		 * ---------------------------------------------------------------------------------------------
		 */
		$db->setQuery("SELECT id FROM #__jfusion WHERE name = ".$db->Quote($name));
		if (!$db->Query()) {
			// Install failed, roll back changes
			$this->parent->abort(JText::_('Plugin').' '.JText::_('Install').': '.$db->stderr(true));
			return false;
		}
		$id = $db->loadResult();

		// Was there a module already installed with the same name?
		if ($id) {

			if (!$this->parent->getOverwrite())
			{
				// Install failed, roll back changes
				$this->parent->abort(JText::_('Plugin').' '.JText::_('Install').': '.JText::_('Plugin').' "'.$pname.'" '.JText::_('already exists!'));
				return false;
			}

		} else {
			// TODO: use JTable and remove hardcoded SQL
			$db->setQuery("INSERT INTO #__jfusion (name, description) VALUES (".$db->Quote($name).",".$db->Quote($myDesc).")");
			if (!$db->Query()) echo "OWNED". $db->getQuery();
			$this->parent->pushStep(array ('type' => 'plugin', 'id' => $row->id));
		}
		
		/**
		 * ---------------------------------------------------------------------------------------------
		 * Finalization and Cleanup Section
		 * ---------------------------------------------------------------------------------------------
		 */

		// Lastly, we will copy the manifest file to its appropriate place.
		if (!$this->parent->copyManifest(-1)) {
			// Install failed, rollback changes
			$this->parent->abort(JText::_('Plugin').' '.JText::_('Install').': '.JText::_('Could not copy setup file'));
			return false;
		}
		return true;
	}
	
	function uninstall($jname) {
		$dir = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jfusion'.DS.'plugins'.DS. $jname;
		
		if (!$jname || !JFolder::exists($dir)) {			
			$this->parent->abort(JText::_('Plugin path does not exist'));
			return false;
		}
		// remove files
		if (!JFolder::delete($dir)) {
			$this->parent->abort(JText::_('Could not delete plugin folder!'));
			return false;
		} 
		
		$db =& JFactory::getDBO();
		
		// delete raw
		$db->setQuery("DELETE FROM #__jfusion WHERE name = ". $db->Quote($jname));
		if(!$db->Query()) {
			$this->parent->abort(JText::_('Owned!'));
		}

	}
	
	/**
	 * load manifest file with installation information
	 * @return simpleXML object (or null)
	 * @param $dir string - Directory
	 */
	function _getManifest($dir) {		
		// Initialize variables
		$null	= null;
		$xml	=& JFactory::getXMLParser('Simple');

		// TODO: DISCUSS if we should allow flexible naming for installation file
		$this->parent->setPath('manifest', $dir.'/jfusion.xml');
		// If we cannot load the xml file return null
		if (!$xml->loadFile($dir."/jfusion.xml")) {
			// Free up xml parser memory and return null
			unset ($xml);
			return $null;
		}

		/*
		 * Check for a valid XML root tag.
		 * @todo: Remove backwards compatability in a future version
		 * Should be 'install', but for backward compatability we will accept 'mosinstall'.
		 */
		$root =& $xml->document;
		if (!is_object($root) || ($root->name() != 'install' && $root->name() != 'mosinstall')) {
			// Free up xml parser memory and return null
			unset ($xml);
			return $null;
		}

		// Valid manifest file return the object
		return $xml;
	
		
	}
	
	
}
