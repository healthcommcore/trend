<?php
/**
* @package com_jfusion
* @version 1.0.5
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

/** ensure this file is being included by a parent file */
defined('_JEXEC' ) or die('Restricted access' );

/**
* Class that handles the html output of all admin functions
*/
class jfusionScreens {

    /**
* Renders the configuration screen of an individual integration
*/
    function jfusionconfig($jname, $form)
    {
        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'save', JText::_('SAVE'), 'save', false, false );
        $bar->appendButton('Standard', 'cancel', JText::_('CANCEL'), 'cancel', false, false );
        echo $bar->render();
        //print string
        echo '<table><tr><td><img src="components/com_jfusion/images/jfusion_logo.jpg"></td><td><h2>'.  $jname . ' Configuration</h2></td></tr></table>';
        echo $form;
        echo '<input type="hidden" name="jname" value="' . $jname . '">';
    }


    function mainConfig($output)
    {
        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'save', JText::_('SAVE'), 'save_main', false, false );
        $bar->appendButton('Standard', 'cancel', JText::_('CANCEL'), 'cancel', false, false );
        echo $bar->render();
        echo "<br><br>$output <br><br>";
        echo '<h2>' . JText::_('USERMODE_HEADER'). '</h2><font size="2">' . JText::_('USERMODE_1') . '<br><br>' . JText::_('USERMODE_2') . '</font><br><br>';
        echo '<br><h2>' . JText::_('USERNAME_FILTER_HEADER'). '</h2><font size="2">' . JText::_('USERNAME_FILTER_TEXT') . '</font><br><br>';
        echo '<br><h2>' . JText::_('JOOMLA_USERGROUP_HEADER'). '</h2><font size="2">' . JText::_('JOOMLA_USERGROUP_TEXT') . '</font><br><br>';

        ;


    }

    /**
* Renders the main admin screen that shows the configuration overview of all integrations
*/
    function showInstall($results)
    {
        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'edit', JText::_('EDIT'), 'config', false, false );
        $bar->appendButton('Standard', 'unpublish', JText::_('DISABLE'), 'unpublish', false, false );
        $bar->appendButton('Standard', 'publish', JText::_('ENABLE'), 'publish', false, false );
        $bar->appendButton('Standard', 'help', JText::_('WIZARD'), 'wizard', false, false );
        $bar->appendButton('Standard', 'adduser', JText::_('USER_SYNC'), 'sync', false, false );
   		$bar->appendButton('Standard', 'upload', JText::_('UPLOAD'), 'add_plugin', false, false );
		$bar->appendButton('Standard', 'delete', JText::_('REMOVE'), 'remove_plugin', false, false );
        echo $bar->render();

        $output = '<img src="components/com_jfusion/images/jfusion_logo.jpg" height="100"><h2> ' . JText::_('CONFIG_OVERVIEW') . '</h2>'.
            '<br><br><table class="adminlist" cellspacing="1"><thead><tr><th class="title" width="20px">' . JText::_('ID') . '</th>'.
        	'<th class="title" nowrap="nowrap">' . JText::_('NAME') . '</th><th class="title" align="center">' . JText::_('DESCRIPTION') . '</th><th class="enabled" width="40px" align="center">' . JText::_('ENABLED') . '</th><th class="enabled" width="40px" align="center">' . JText::_('CHECK_ENCRYPTION') . '</th><th class="enabled" align="center">' . JText::_('STATUS') . '</th><th class="autosetup" width="80px" align="center">' . JText::_('WIZARD') . '</th><th class="enabled" width="80px" align="center">' . JText::_('DUAL_LOGIN') . '</th></tr></thead><tbody>';

        foreach($results as $record ) {
            $output .= "<tr><td>$record->id</td><td><INPUT TYPE=RADIO NAME=\"jname\" VALUE=\"$record->name\">$record->name</td><td>$record->description</td>";

            //check to see if module is enabled
            if ($record->enabled =='1') {
                $output .= "<td><a href=\"javascript:void(0);\" onclick=\"setCheckedValue(document.adminForm.jname, '$record->name'); submitbutton('unpublish')\" title=\"Disable Plugin\"><img src=\"images/tick.png\" border=\"0\" alt=\"Enabled\" /></a></td>";
            } else {
                $output .= "<td><a href=\"javascript:void(0);\" onclick=\"setCheckedValue(document.adminForm.jname, '$record->name'); submitbutton('publish')\" title=\"Enable Plugin\"><img src=\"images/publish_x.png\" border=\"0\" alt=\"Disabled\" /></a></td>";
            }

            //check to see if password encryption is enabled
            if ($record->check_encryption =='1') {
                $output .= "<td><a href=\"javascript:void(0);\" onclick=\"setCheckedValue(document.adminForm.jname, '$record->name'); submitbutton('disable_encryption')\" title=\"Disable Encryption\"><img src=\"images/tick.png\" border=\"0\" alt=\"Enabled\" /></a></td>";
            } else {
                $output .= "<td><a href=\"javascript:void(0);\" onclick=\"setCheckedValue(document.adminForm.jname, '$record->name'); submitbutton('enable_encryption')\" title=\"Enable Encryption\"><img src=\"images/publish_x.png\" border=\"0\" alt=\"Disabled\" /></a></td>";
            }
            

            //prepare an array of status messages
            $status = array(JText::_('NO_CONFIG'), JText::_('NO_DATABASE'), JText::_('NO_TABLE'), JText::_('GOOD_CONFIG'));
            
            //check to see what the config status is
            if ($record->status == '3') {
                $output .= '<td><img src="images/tick.png" border="0" alt="Good Config" />' . $status[$record->status] . '</td>';
            } else {
                $output .= '<td><img src="images/publish_x.png" border="0" alt="Wrong Config" /> ' . $status[$record->status] . '</td>';
            }
            

            //check to see if setup wizard is supported
            if ($record->wizard =='1') {
                $output .= '<td><img src="images/tick.png" border="0" alt="Enabled" />Supported</td>"';
            } else {
                $output .= '<td><img src="images/publish_x.png" border="0" alt="Disabled" />Not Available</td>"';
            }

            //check to see if cookies are supported
            if ($record->cookie =='1') {
                $output .= '<td><img src="images/tick.png" border="0" alt="Enabled" />Supported</td></tr>"';
            } else {
                $output .= '<td><img src="images/publish_x.png" border="0" alt="Disabled" />Not Available</td></tr>"';
            }


        }
        $output .= '</tbody></table>';
        echo $output;
    }

    /**
* Renders the help screen in the Joomla administration
*/
    function jfusionhelp()
    {
        echo '<table><tr><td><img src="components/com_jfusion/images/jfusion_logo.jpg"></td><td><h1>' . JText::_('HELP_HEADER') .  '</h1></td></tr></table><h1><b>' . JText::_('HELP_WARNING') . '</b></h1><br><font size="2">';
        echo  JText::_('HELP_ABOUT') . '<br><br>' . JText::_('HELP_ABOUT2') . '<br><br><br>' . JText::_('HELP_INSTALL') . '<br><br>' . JText::_('HELP_INSTALL_DETAIL')  . '<br><br><br>' . JText::_('HELP_ADV') . '<br><br>' . JText::_('HELP_ADV_DETAIL');
        echo '<br><br><h2>' . JText::_('WRAPPER_HEADER') . '</h2><br>';
        echo '<font size="2">' . JText::_('WRAPPER_TEXT') . '</font><br>';
        echo '<br><br><br><h2>' . JText::_('HELP_FEEDBACK') . '</h2><br><br>' . JText::_('HELP_FEEDBACK_DETAIL');


    }

    /**
* Renders the wizard screen for an individual integration and allows entry of the forum path
*/
    function jfusionwizard($jname)
    {
        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'forward', JText::_('NEXT'), 'wizard_save', false, false );
        $bar->appendButton('Standard', 'cancel', JText::_('CANCEL'), 'cancel', false, false );
        echo $bar->render();
        echo '<table><tr><td><img src="components/com_jfusion/images/jfusion_logo.jpg" height="100"></td><td><h2>' . JText::_('WIZARD_WELCOME') . ' for ' . $jname . '</h2></td></tr></table><br><br><font size="2">' . JText::_('WIZARD_INSTR') . '</font><br><br>';
        echo'<br><table width="100%" class="paramlist admintable" cellspacing="1"><tr width="100%"><td class="paramlist_key"><span class="editlinktip"><label id="paramsdatabase_host-lbl" for="paramssource_path" class="hasTip" title="Path">' . JText::_('WIZARD_PATH') . '</label></span></td><td class="paramlist_value"><input type="text" name="params[source_path]" id="paramssource_path" value="' . JPATH_ROOT .'" class="text_area" size="50" /></td></tr></table>';
        echo '<br><font size="2">' . JText::_('WIZARD_INSTR2') . '</font><br>';
        echo '<input type=hidden name=jname value="' . $jname . '">';
    }

    /**
* Renders the result wizard screen for an individual integration
*/
    function jfusionwizard_config($jname, $form)
    {
        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'save', JText::_('SAVE'), 'save', false, false );
        $bar->appendButton('Standard', 'apply', JText::_('APPLY'), 'apply', false, false );
        $bar->appendButton('Standard', 'cancel', JText::_('CANCEL'), 'cancel', false, false );
        echo $bar->render();
        echo '<table><tr><td><img src="components/com_jfusion/images/jfusion_logo.jpg"></td><td><h2>' . JText::_('WIZARD_RESULT') . '</h2></td></tr></table>' . JText::_('WIZARD_SUCCESS') . '<br/><br/>';
        echo '<input type=hidden name=jname value="' . $jname . '">';
        echo $form;
    }


    /**
* Echos a form that allows information to be submitted back to the component
*/
    function startForm()
    {
        echo '<script language="javascript" type="text/javascript">
<!--
function submitbutton(pressbutton) {
var form = document.adminForm;
submitform(pressbutton);
return;
}

function setCheckedValue(radioObj, newValue) {
	if(!radioObj)
		return;
	var radioLength = radioObj.length;
	if(radioLength == undefined) {
		radioObj.checked = (radioObj.value == newValue.toString());
		return;
	}
	for(var i = 0; i < radioLength; i++) {
		radioObj[i].checked = false;
		if(radioObj[i].value == newValue.toString()) {
			radioObj[i].checked = true;
		}
	}
}

//-->
</script>
<form method="post" action="index2.php" name="adminForm">
<input type="hidden" name="option" value="com_jfusion" />
<input type="hidden" name="task" value="" />';
    }

    /**
* Closes the form
*/
    function endForm()
    {
        echo '</form>';
    }

    /**
* Displays information on the discrepancies between the Joomla and forum integration
*/
    function jfusionsync($jname)
    {
        echo '<h2>' . JText::_('SYNC_HEADER') . '</h2><br/><font size="2">' . JText::_('SYNC_INTRO') . '<br/><br/><b>' . JText::_('SYNC_WARNING') . '</b><br/><br/>' . JText::_('SYNC_INSTR');
        echo '<br><br><select name="email_conflict"> <option value="1" selected="selected">' . JText::_('EMAIL_CONFLICT_1') . '</option><option value="2">' . JText::_('EMAIL_CONFLICT_2') . '</option><option value="3">' . JText::_('EMAIL_CONFLICT_3') . '</option></select></font>';

        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'adduser', JText::_('USER_SYNC'), 'apply_sync', false, false );
        $bar->appendButton('Standard', 'cancel', JText::_('CANCEL'), 'cancel', false, false );
        echo $bar->render() . '<br><br><br><br><br><br>';
        echo '<input type="hidden" name="jname" value="' . $jname . '">';

                

       

    }

    

    	function add_plugin() {
		?>
		<script language="javascript" type="text/javascript">
<!--
function submitbutton(pressbutton) {
var form = document.adminForm;
submitform(pressbutton);
return;
}

	function submitbutton3(pressbutton) {
		var form = document.adminForm;

		// do field validation
		if (form.install_directory.value == ""){
			alert( "<?php echo JText::_( 'Please select a directory', true ); ?>" );
		} else {
			form.installtype.value = 'folder';
			form.submit();
		}
	}

	function submitbutton4(pressbutton) {
		var form = document.adminForm;

		// do field validation
		if (form.install_url.value == "" || form.install_url.value == "http://"){
			alert( "<?php echo JText::_( 'Please enter a URL', true ); ?>" );
		} else {
			form.installtype.value = 'url';
			form.submit();
		}
	}

//-->
</script>
<form method="post" action="index2.php" name="adminForm" enctype="multipart/form-data">
<input type="hidden" name="option" value="com_jfusion" />
<input type="hidden" name="task" value="install_plugin" />
		<table class="adminform">
	<tr>
		<th colspan="2"><?php echo JText::_( 'Upload Package File' ); ?></th>
	</tr>
	<tr>
		<td width="120">
			<label for="install_package"><?php echo JText::_( 'Package File' ); ?>:</label>
		</td>
		<td>
			<input class="input_box" id="install_package" name="install_package" type="file" size="57" />
			<input class="button" type="button" value="<?php echo JText::_( 'Upload File' ); ?> &amp; <?php echo JText::_( 'Install' ); ?>" onclick="submitbutton()" />
		</td>
	</tr>
	</table>

	<table class="adminform">
	<tr>
		<th colspan="2"><?php echo JText::_( 'Install from directory' ); ?></th>
	</tr>
	<tr>
		<td width="120">
			<label for="install_directory"><?php echo JText::_( 'Install directory' ); ?>:</label>
		</td>
		<td>
			<input type="text" id="install_directory" name="install_directory" class="input_box" size="70" value="" />
			<input type="button" class="button" value="<?php echo JText::_( 'Install' ); ?>" onclick="submitbutton3()" />
		</td>
	</tr>
	</table>

	<table class="adminform">
	<tr>
		<th colspan="2"><?php echo JText::_( 'Install from URL' ); ?></th>
	</tr>
	<tr>
		<td width="120">
			<label for="install_url"><?php echo JText::_( 'Install URL' ); ?>:</label>
		</td>
		<td>
			<input type="text" id="install_url" name="install_url" class="input_box" size="70" value="http://" />
			<input type="button" class="button" value="<?php echo JText::_( 'Install' ); ?>" onclick="submitbutton4()" />
		</td>
	</tr>
	</table>

	<input type="hidden" name="type" value="" />
	<input type="hidden" name="installtype" value="upload" />

	<?php
	}
    
    function ajax_sync($syncid) {
    ?>
    <script language="javascript" type="text/javascript">
<!--
//Browser Support Code
function ajaxFunction(){
	var ajaxRequest;  // The variable that makes Ajax possible!

	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			document.myForm.time.value = ajaxRequest.responseText;
		}
	}
	ajaxRequest.open("GET", "http://www.jfusion.org/administrator/index.php?option=com_jfusion&task=ajax_sync_status", true);
	ajaxRequest.send(null);
}

//-->
</script>



<form name='myForm'>
<input type='hidden' name ='syncid' value='<? echo $syncid; ?>'>
Name: <input type='text' onChange="ajaxFunction();" name='username' /> <br />
Time: <input type='text' name='time' />
</form>

<?php
    }
    
        function check_login_form()
    {
        $bar =& new JToolBar('My Toolbar' );
        $bar->appendButton('Standard', 'forward', JText::_('CHECK_LOGIN'), 'check_login', false, false );
        $bar->appendButton('Standard', 'cancel', JText::_('CANCEL'), 'cancel', false, false );
        echo $bar->render();

        echo '<h2>JFusion Login Tester</h2><br><font size="2">This login tester allows you to test out JFusion logins without the need to publish the JFusion auth/user plugins. You can use this tool to find out what the problem is when JFusion login is not behaving as expected</font><br><br>';
        echo 'username: <input type="text" name="check_username"><br>Password:<input type="password" name="check_password">';

    }
    
    
    
    
    
}
?>

