CREATE TABLE IF NOT EXISTS #__jfusion (
  id int(11) NOT NULL auto_increment,
  name varchar(50) NOT NULL,
  description varchar(150) NOT NULL,
  params text,
  enabled tinyint(4) NOT NULL,
  status tinyint(4) NOT NULL,
  wizard tinyint(4) NOT NULL,
  cookie tinyint(4) NOT NULL,
  config tinyint(4) NOT NULL,
  check_encryption tinyint(4) NOT NULL,
  PRIMARY KEY  (id)
);

INSERT INTO #__jfusion  (name ,description, params, enabled, wizard, cookie, status, config, check_encryption) 
VALUES ('vbulletin', 'vBulletin 3.6.8', '', 0, 1, 1, 0, 0, 0);
INSERT INTO #__jfusion  (name ,description, params, enabled, wizard, cookie, status, config, check_encryption)
VALUES ('phpbb3', 'phpBB3', '', 0, 1, 1, 0, 0, 0);
INSERT INTO #__jfusion  (name ,description, params, enabled, wizard, cookie, status, config, check_encryption)
VALUES ('smf', 'SMF 1.1.4', '', 0, 1, 0, 0, 0, 0);
INSERT INTO #__jfusion  (name ,description, params, enabled, wizard, cookie, status, config, check_encryption)
VALUES ('mybb', 'myBB 1.2.12', '', 0, 1, 1, 0, 0, 0);
INSERT INTO #__jfusion  (name ,description, params, enabled, wizard, cookie, status, config, check_encryption)
VALUES ('ipb', 'ipb', '', 0, 1, 1, 0, 0, 0);
INSERT INTO #__jfusion  (name ,description, params, enabled, wizard, cookie, status, config, check_encryption)
VALUES ('punbb', 'PunBB', '', 0, 1, 1, 0, 0, 0);


CREATE TABLE IF NOT EXISTS #__jfusion_user_lookup (
	id int(11) NOT NULL auto_increment,
	juser_id int(11) NOT NULL,
	plugin_user_id int(11) NOT NULL,
	plugin_username varchar(50) character set utf8 collate utf8_bin NOT NULL,
	plugin_name varchar(50) NOT NULL,
	PRIMARY KEY (id)
);
