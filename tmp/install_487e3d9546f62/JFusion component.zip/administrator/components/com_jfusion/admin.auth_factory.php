<?php

/**
* @package com_jfusion
* @version 1.0.5
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );
require_once( JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');

/**
 * Singleton static only class that creates instances of abstract forum to implement the required functionality
 * for each specific bulletin board that is integrated with.
 *
 */
class AuthFactory{

	/**
	 * Gets an AbstractForum of the correct type for the configured forum integration
	 *
	 * @return AbstractForum
	 */
	function &getAuth($jname){

			//initialise the forum based on the type selected in configuration
            if ($jname) {
               require_once( JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/' . $jname . '/auth.php');
               $class = $jname . "_auth";
               $model = new $class;
               return $model;
            } else {
               //return false
               return false;
            }

	}


}
?>
