<?php
// $Id: array_diff_key.php,v 1.9 2007/04/17 10:09:56 arpad Exp $


/**
 * Replace array_diff_key()
 *
 * @category    PHP
 * @package     PHP_Compat
 * @license     LGPL - http://www.gnu.org/licenses/lgpl.html
 * @copyright   2004-2007 Aidan Lister <aidan@php.net>, Arpad Ray <arpad@php.net>
 * @link        http://php.net/function.array_diff_key
 * @author      Tom Buskens <ortega@php.net>
 * @version     $Revision: 1.9 $
 * @since       PHP 5.0.2
 * @require     PHP 4.0.0 (user_error)
 */
function php_compat_array_diff_key()
{
    $args = func_get_args();
    if (count($args) < 2) {
        user_error('Wrong parameter count for array_diff_key()', E_USER_WARNING);
        return;
    }

    // Check arrays
    $array_count = count($args);
    for ($i = 0; $i !== $array_count; $i++) {
        if (!is_array($args[$i])) {
            user_error('array_diff_key() Argument #' .
                ($i + 1) . ' is not an array', E_USER_WARNING);
            return;
        }
    }

    $result = $args[0];
    if (function_exists('array_key_exists')) {
        // Optimize for >= PHP 4.1.0
        foreach ($args[0] as $key => $value) {
            for ($i = 1; $i !== $array_count; $i++) {
                if (array_key_exists($key,$args[$i])) {
                    unset($result[$key]);
                    break;
                }
            }
        }
    } else {
        foreach ($args[0] as $key1 => $value1) {
            for ($i = 1; $i !== $array_count; $i++) {
                foreach ($args[$i] as $key2 => $value2) {
                    if ((string) $key1 === (string) $key2) {
                        unset($result[$key2]);
                        break 2;
                    }
                }
            }
        }
    }
    return $result;
}


// Define
if (!function_exists('array_diff_key')) {
    function array_diff_key()
    {
        $args = func_get_args();
        return call_user_func_array('php_compat_array_diff_key', $args);
    }
}



// $Id: array_diff_assoc.php,v 1.16 2007/04/17 10:09:56 arpad Exp $


/**
 * Replace array_diff_assoc()
 *
 * @category    PHP
 * @package     PHP_Compat
 * @license     LGPL - http://www.gnu.org/licenses/lgpl.html
 * @copyright   2004-2007 Aidan Lister <aidan@php.net>, Arpad Ray <arpad@php.net>
 * @link        http://php.net/function.array_diff_assoc
 * @author      Aidan Lister <aidan@php.net>
 * @version     $Revision: 1.16 $
 * @since       PHP 4.3.0
 * @require     PHP 4.0.0 (user_error)
 */
function php_compat_array_diff_assoc()
{
    // Check we have enough arguments
    $args = func_get_args();
    $count = count($args);
    if (count($args) < 2) {
        user_error('Wrong parameter count for array_diff_assoc()', E_USER_WARNING);
        return;
    }

    // Check arrays
    for ($i = 0; $i < $count; $i++) {
        if (!is_array($args[$i])) {
            user_error('array_diff_assoc() Argument #' .
                ($i + 1) . ' is not an array', E_USER_WARNING);
            return;
        }
    }

    // Get the comparison array
    $array_comp = array_shift($args);
    --$count;

    // Traverse values of the first array
    foreach ($array_comp as $key => $value) {
        // Loop through the other arrays
        for ($i = 0; $i < $count; $i++) {
            // Loop through this arrays key/value pairs and compare
            foreach ($args[$i] as $comp_key => $comp_value) {
                if ((string)$key === (string)$comp_key &&
                    (string)$value === (string)$comp_value)
                {

                    unset($array_comp[$key]);
                }
            }
        }
    }

    return $array_comp;
}


// Define
if (!function_exists('array_diff_assoc')) {
    function array_diff_assoc()
    {
        $args = func_get_args();
        return call_user_func_array('php_compat_array_diff_assoc', $args);
    }
}


// $Id: array_intersect_assoc.php,v 1.8 2007/04/17 10:09:56 arpad Exp $


/**
 * Replace array_intersect_assoc()
 *
 * @category    PHP
 * @package     PHP_Compat
 * @license     LGPL - http://www.gnu.org/licenses/lgpl.html
 * @copyright   2004-2007 Aidan Lister <aidan@php.net>, Arpad Ray <arpad@php.net>
 * @link        http://php.net/function.array_intersect_assoc
 * @author      Aidan Lister <aidan@php.net>
 * @version     $Revision: 1.8 $
 * @since       PHP 4.3.0
 * @require     PHP 4.0.0 (user_error)
 */
function php_compat_array_intersect_assoc()
{
    // Sanity check
    $args = func_get_args();
    if (count($args) < 2) {
        user_error('wrong parameter count for array_intersect_assoc()', E_USER_WARNING);
        return;
    }

    // Check arrays
    $array_count = count($args);
    for ($i = 0; $i !== $array_count; $i++) {
        if (!is_array($args[$i])) {
            user_error('array_intersect_assoc() Argument #' .
                ($i + 1) . ' is not an array', E_USER_WARNING);
            return;
        }
    }

    // Compare entries
    $intersect = array();
    foreach ($args[0] as $key => $value) {
        $intersect[$key] = $value;

        for ($i = 1; $i < $array_count; $i++) {
            if (!isset($args[$i][$key]) || $args[$i][$key] != $value) {
                unset($intersect[$key]);
                break;
            }
        }
    }

    return $intersect;
}


// Define
if (!function_exists('array_intersect_assoc')) {
    function array_intersect_assoc()
    {
        $args = func_get_args();
        return call_user_func_array('php_compat_array_intersect_assoc', $args);
    }
}


function php_compat_array_intersect_key()
{
    $args = func_get_args();
    $array_count = count($args);
    if ($array_count < 2) {
        user_error('Wrong parameter count for array_intersect_key()', E_USER_WARNING);
        return;
    }

    // Check arrays
    for ($i = $array_count; $i--;) {
        if (!is_array($args[$i])) {
            user_error('array_intersect_key() Argument #' .
                ($i + 1) . ' is not an array', E_USER_WARNING);
            return;
        }
    }

    // Intersect keys
    $arg_keys = array_map('array_keys', $args);
    $result_keys = call_user_func_array('array_intersect', $arg_keys);

    // Build return array
    $result = array();
    foreach($result_keys as $key) {
        $result[$key] = $args[0][$key];
    }
    return $result;
}


// Define
if (!function_exists('array_intersect_key')) {
    function array_intersect_key()
    {
        $args = func_get_args();
        return call_user_func_array('php_compat_array_intersect_key', $args);
    }
}


?>

