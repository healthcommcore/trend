<?php

/**
* JFusion plugin for vbulletin 3.6.8
*
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

//load the JFusion framework
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');



class CustomForum extends AbstractForum{

    function &getUser($username)
    {
        // Get user info from database
        $db = AbstractForum::getDatabase('vbulletin');
        $query = 'SELECT userid, username,email, password, salt as password_salt FROM `#__user` WHERE username=' . $db->Quote($username);
        $db->setQuery($query );
        $result = $db->loadObject();

        if ($result) {
             //Check to see if they are banned
            $query = 'SELECT userid FROM `#__userban` WHERE userid='.$result->userid;
            $db->setQuery($query);
            if ($db->loadObject()) {
                $result->block = 1;
            } else {
                $result->block = 0;
            }
            
        }

            return $result;

    }


            /**
* Returns the name of the forum that is being integrated with.
*/
    function getJname()
    {
        return "vbulletin";
    }


        /**
* Returns the user table name without the prefix
*/
    function getTablename()
    {
    return 'user';
    }
    
        function setupFromPath($forumPath)
    {
        //check for trailing slash and generate file path
        if (substr($forumPath, -1) == '/') {
            $myfile = $forumPath . "includes/config.php";
        } else {
            $myfile = $forumPath . "/includes/config.php";
        }

        //try to open the file
        if (($file_handle = @fopen($myfile, 'r')) === FALSE) {
            JError::raiseWarning(500,JText::_('WIZARD_FAILURE'). ": $myfile " . JText::_('WIZARD_MANUAL'));

            //get the default parameters object
            $params = AbstractForum::getSettings($this->getJname());
            return $params;


         } else {

            //parse the file line by line to get only the config variables
            $file_handle = fopen($myfile, 'r');
            while (!feof($file_handle)) {
                $line = fgets($file_handle);
                if (strpos($line, '$config') === 0) {
                    $vars = split ("'", $line);
                    $name1 = trim($vars[1], ' $=');
                    $name2 = trim($vars[3], ' $=');
                    $value = trim($vars[5], ' $=');
                    $config[$name1][$name2] = $value;

                } else if (strpos($line, 'Licence Number')) {
                    //extract the vbulletin license code while we are at it
                    $vb_lic = substr($line, strpos($line, 'Licence Number') + 14, strlen($line));
                }
            }
            fclose($file_handle);

            //load the params from the component and add in the ones from the vbulletin config file
            $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/vbulletin/jfusion.xml';
            $params = new JParameter('', $file );

            $params->set('database_host', $config['MasterServer']['servername'] );
            $params->set('database_type', $config['Database']['dbtype'] );
            $params->set('database_name', $config['Database']['dbname'] );
            $params->set('database_user', $config['MasterServer']['username'] );
            $params->set('database_password', $config['MasterServer']['password'] );
            $params->set('database_prefix', $config['Database']['tableprefix'] );
            $params->set('cookie_prefix', $config['Misc']['cookieprefix'] );

            //find the path to vbulletin, for this we need a database connection
            $host = $config['MasterServer']['servername'];
            $user = $config['MasterServer']['username'];
            $password = $config['MasterServer']['password'];
            $database = $config['Database']['dbname'];
            $prefix = $config['Database']['tableprefix'];
            $driver = 'mysql';
            $options = array('driver' => $driver, 'host' => $host, 'user' => $user, 'password' => $password, 'database' => $database, 'prefix' => $prefix );
            $vdb =& JDatabase::getInstance($options );
            //Find the path to vbulletin
            $query = "SELECT value FROM #__setting WHERE varname = 'bburl'";
            $vdb->setQuery($query);
            $vb_url = $vdb-> loadResult();
            $params->set('source_url', $vb_url);
            
            $query = "SELECT value FROM #__setting WHERE varname = 'cookiedomain'";
            $vdb->setQuery($query);
            $cookie_domain = $vdb-> loadResult();
            $params->set('cookie_domain', $cookie_domain);

            $query = "SELECT value FROM #__setting WHERE varname = 'cookiepath'";
            $vdb->setQuery($query);
            $cookie_path = $vdb-> loadResult();
            $params->set('cookie_path', $cookie_path);

            
            $params->set('source_license', trim($vb_lic));
            

            JError::raiseNotice(0,JText::_('WIZARD_SUCCESS'));
            return $params;
        }
    }

    function destroyForumCookie()
    {
        // Get the parameters
        $params = AbstractForum::getSettings('vbulletin');

        //Clear the vBulletin Cookie
        $vbCookiePrefix = $params->get('cookie_prefix','bb');
        $vbCookieDomain = $params->get('cookie_domain');
        $vbCookiePath = $params->get('cookie_path');

        setcookie($vbCookiePrefix."userid", " ", time() - 1800, $vbCookiePath, $vbCookieDomain );
        setcookie($vbCookiePrefix."password", " ", time() - 1800, $vbCookiePath, $vbCookieDomain );
        setcookie($vbCookiePrefix."styleid", " ", time() - 1800, $vbCookiePath, $vbCookieDomain );
        setcookie($vbCookiePrefix."sessionhash", " ", time() - 1800, $vbCookiePath, $vbCookieDomain );
    }

    function createForumCookie($instance,$options, $session)
    {
        //Now set-up the vBulletin cookie for single sign-in
        // Get a database object, and prepare some basic data
        $db = AbstractForum::getDatabase('vbulletin');
        $params = AbstractForum::getSettings('vbulletin');

        $query = "SELECT userid,username,salt,password FROM #__user WHERE username = ".$db->Quote($instance->get('username'));
        $db->setQuery($query);
        $vbUserData = $db->loadObject();

        $vbCookiePrefix = $params->get('cookie_prefix','bb');
        $vbCookieDomain = $params->get('cookie_domain');
        $vbCookiePath = $params->get('cookie_path');
        $vbLicense = $params->get('source_license','');

        $bypost = 1;

        //TODO: This should determine if the user is logged on from a cookie
        //		$vbUserCookie = trim(mosGetParam($_POST, 'cookieuser', '' ) );

        setcookie($vbCookiePrefix."userid", $vbUserData->userid, time() + 43200, $vbCookiePath, $vbCookieDomain );
        setcookie($vbCookiePrefix."password", md5($vbUserData->password . $vbLicense ), time() + 43200, $vbCookiePath, $vbCookieDomain );
        setcookie("userid", $vbUserData->userid, time() + 43200, "/" );

        //TODO: Validate how we pick up the "Rember Me thing"
        if (isset($options['remember']) OR isset($session->user)) {
            $lifetime = time() + 365*24*60*60;
            setcookie("usercookie[username]", $vbUserData->username, $lifetime, "/" );
            setcookie("usercookie[password]", $vbUserData->password, $lifetime, "/" );
            setcookie($vbCookiePrefix."userid", $vbUserData->userid, $lifetime, $vbCookiePath, $vbCookieDomain );
            setcookie($vbCookiePrefix."password", md5($vbUserData->password . $vbLicense ), $lifetime, $vbCookiePath, $vbCookieDomain );
            setcookie("userid", $session->userid, $lifetime, "/" );
        }
    }
    
    function getPrivateMessageCounts($forumuserid)
    {
       $db = AbstractForum::getDatabase('vbulletin');
       $params = AbstractForum::getSettings('vbulletin');
       
       $query = "SELECT pmtotal,pmunread FROM #__user WHERE userid = ".$db->Quote($forumuserid);
       $db->setQuery($query);
       $vbPMData = $db->loadObject();
       
       $pmcount["total"] = $vbPMData->pmtotal;
       $pmcount["unread"] = $vbPMData->pmunread;
       
       return $pmcount;
    }

    function getPrivateMessageURL()
    {
       return AbstractForum::createURL('private.php', 'vbulletin');
    }
    
    function getViewNewMessagesURL()
    {
       return AbstractForum::createURL('search.php?do=getnew', 'vbulletin');
    }
    
    
    
    function getAvatar($userid)
    {
        if ($userid)
        {
                $params = AbstractForum::getSettings('vbulletin');
                $url = $params->get('source_url').'image.php?u='.$userid .'&dateline='. time() ;
                return $url;

            } else {

        return 0;
        }
    }
    
    

    function getRegistrationURL()
    {
       return AbstractForum::createURL('register.php', 'vbulletin');
    }

    function getLostPasswordURL()
    {
       return AbstractForum::createURL('login.php?do=lostpw', 'vbulletin');
    }

    function getLostUsernameURL()
    {
       return AbstractForum::createURL('login.php?do=lostpw', 'vbulletin');
    }
    
    function getThreadURL($threadid, $subject)
    {
        return  AbstractForum::createURL('showthread.php?t=' . $threadid, 'vbulletin');

    }
    
    function getPostURL($threadid, $postid, $subject)
    {
        return  AbstractForum::createURL('showthread.php?p='.$postid.'#post' . $postid, 'vbulletin');
    }
    
    function getProfileURL($uid,$uname)
    {
        return  AbstractForum::createURL('member.php?u='.$uid, 'vbulletin');
    }

    function getQuery($usedforums, $result_order, $result_limit)
    {
if ($usedforums) {
$where = ' WHERE a.forumid IN (' . $usedforums .')';
} else {
$where = '';
}

$query = array ( 0 => array( 0 => "SELECT a.threadid , b.username, b.userid, b.title, b.dateline, left(b.pagetext, $result_limit) FROM `#__thread` as a INNER JOIN `#__post` as b ON a.firstpostid = b.postid " . $where . " ORDER BY a.lastpost  ".$result_order." LIMIT 0,".$result_limit.";",
                             1 => "SELECT a.threadid , b.username, b.userid, b.title, b.dateline, left(b.pagetext, $result_limit) FROM `#__thread` as a INNER JOIN `#__post` as b ON a.lastpostid = b.postid " . $where . " ORDER BY a.lastpost  ".$result_order." LIMIT 0,".$result_limit.";"),
                 1 => array( 0 => "SELECT a.threadid , b.username, b.userid, b.title, b.dateline, left(b.pagetext, $result_limit) FROM `#__thread` as a INNER JOIN `#__post` as b ON a.firstpostid = b.postid " . $where . " ORDER BY a.dateline  ".$result_order." LIMIT 0,".$result_limit.";",
                             1 => "SELECT a.threadid , b.username, b.userid, b.title, b.dateline, left(b.pagetext, $result_limit) FROM `#__thread` as a INNER JOIN `#__post` as b ON a.lastpostid = b.postid " . $where . " ORDER BY a.dateline  ".$result_order." LIMIT 0,".$result_limit.";"),
                 2 => array( 0 => "SELECT a.postid , a.username, a.userid, a.title, a.dateline, a.pagetext, a.threadid FROM `#__post` as a INNER JOIN `#__thread` as b ON a.threadid = b.threadid " . $where . " ORDER BY a.dateline ".$result_order." LIMIT 0,".$result_limit.";",
                             1 => "SELECT a.postid , a.username, a.userid, a.title, a.dateline, a.pagetext, a.threadid FROM `#__post` as a INNER JOIN `#__thread` as b ON a.threadid = b.threadid " . $where . " ORDER BY a.dateline ".$result_order." LIMIT 0,".$result_limit.";")
                 );


return $query;

    }




    function getForumUsers() {
    //getting the connection to the db
	$db = abstractForum::getDatabase('vbulletin');
    $query = 'SELECT username, email from #__user';
    $db->setQuery( $query );

	//getting the results
    $rows = $db->loadObjectList();

	//parse it into an array for later comparison
	foreach ( $rows as $record ) {
    $userlist[$record->username] = $record->email;
    }

    return $userlist;

	}
	
	        function filterUsername($username) {
    //no username filtering implemented yet
    return $username;

    }
    
        function getForumList()
    {
        //get the connection to the db

        $db = abstractForum::getDatabase('vbulletin');
        $query = 'SELECT forumid as id, title_clean as name FROM #__forum
            ORDER BY forumid';
        $db->setQuery($query );

        //getting the results
        return $db->loadObjectList();
    }

}
?>
