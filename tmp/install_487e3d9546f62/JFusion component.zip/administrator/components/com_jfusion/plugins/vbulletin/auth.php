<?php

/**
* vbulletin password encryption method
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

class vbulletin_auth extends AuthFactory {

    function generateEncryptedPassword($userinfo)
    {
            $testcrypt = md5(md5($userinfo->password_clear).$userinfo->password_salt);
            return $testcrypt;

    }

}
