<?php

/**
* vbulletin password encryption method
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

class punbb_auth extends AuthFactory {

    function generateEncryptedPassword($userinfo)
    {
            $testcrypt = sha1($userinfo->password_clear);
            return $testcrypt;

    }

}
