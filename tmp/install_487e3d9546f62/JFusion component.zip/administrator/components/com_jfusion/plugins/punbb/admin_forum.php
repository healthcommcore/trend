<?php

/**
* JFusion plugin for punBB 1.2.17
*
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

//load the JFusion framework
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');



class CustomForum extends AbstractForum{

 function &getUser($username)
    {
        // Get user info from database
        $db = AbstractForum::getDatabase('punbb');
        $query = 'SELECT id,username,password,email FROM `#__users` WHERE username=' . $db->Quote($username);
        $db->setQuery($query );
        $result = $db->loadObject();

        if ($result) {
             //Check to see if they are banned
            $query = 'SELECT username FROM `#__bans` WHERE username=' . $db->Quote($username);
            $db->setQuery($query);
            if ($db->loadObject()) {
                $result->block = 1;
            } else {
                $result->block = 0;
            }
            
        }

            return $result;

    }


            /**
* Returns the name of the forum that is being integrated with.
*/
    function getJname()
    {
        return "punbb";
    }


        /**
* Returns the user table name without the prefix
*/
    function getTablename()
    {
    return 'users';
    }
    
        function setupFromPath($forumPath)
    {
        //check for trailing slash and generate file path
        if (substr($forumPath, -1) == '/') {
            $myfile = $forumPath . "config.php";
        } else {
            $myfile = $forumPath . "/config.php";
        }

        //try to open the file
        if (($file_handle = @fopen($myfile, 'r')) === FALSE) {
            JError::raiseWarning(500,JText::_('WIZARD_FAILURE'). ": $myfile " . JText::_('WIZARD_MANUAL'));

            //get the default parameters object
            $params = AbstractForum::getSettings($this->getJname());
            return $params;


         } else {

            //parse the file line by line to get only the config variables
            $file_handle = fopen($myfile, 'r');
            while (!feof($file_handle)) {
                $line = fgets($file_handle);
                if (strpos($line, '$') === 0) {
                    if (strpos($line, '\'') === false) {
                        $name = substr($line,1,strpos($line,' ')-1);
                        $value = substr($line,strpos($line,'=')+2,-2);
                    } else {
                        $vars = split("'", $line);
                        $name = trim($vars[0],' $=');
                        $value = trim($vars[1],' $=');
                    }
                    $config[$name] = $value;
                }

            }
            fclose($file_handle);

            //load the params from the component and add in the ones from the vbulletin config file
            $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/punbb/jfusion.xml';
            $params = new JParameter('', $file );

            $params->set('database_host', $config['db_host'] );
            $params->set('database_type', $config['db_type'] );
            $params->set('database_name', $config['db_name'] );
            $params->set('database_user', $config['db_username'] );
            $params->set('database_password', $config['db_password'] );
            $params->set('database_prefix', $config['db_prefix'] );
            $params->set('cookie_name', $config['cookie_name'] );
			$params->set('cookie_path', $config['cookie_path'] );
			$params->set('cookie_domain', $config['cookie_domain'] );
			$params->set('cookie_seed', $config['cookie_seed'] );
			$params->set('cookie_secure', $config['cookie_secure'] );

            //find the path to PunBB, for this we need a database connection
            $host = $config['db_host'];
            $user = $config['db_username'];
            $password = $config['db_password'];
            $database = $config['db_name'];
            $prefix = $config['db_prefix'];
            $driver = 'mysql';
            $options = array('driver' => $driver, 'host' => $host, 'user' => $user, 'password' => $password, 'database' => $database, 'prefix' => $prefix );
            $pundb =& JDatabase::getInstance($options );
			
            //Find the path to PunBB
            $query = "SELECT conf_value FROM #__config WHERE conf_name = 'o_base_url'";
            $pundb->setQuery($query);
            $pun_url = $pundb-> loadResult();
            $params->set('source_url', $pun_url);
            
            JError::raiseNotice(0,JText::_('WIZARD_SUCCESS'));
            return $params;
        }
    }

    function destroyForumCookie()
    {
        // Get the parameters
        $params = AbstractForum::getSettings('punbb');

        //Clear the vBulletin Cookie
        $punCookie = $params->get('cookie_name');

        setcookie($punCookie, " ", time() - 1800, "/" );
		
    }

    function createForumCookie($instance,$options, $session)
    {
        //Now set-up the vBulletin cookie for single sign-in
        // Get a database object, and prepare some basic data
        $db = AbstractForum::getDatabase('punbb');
        $params = AbstractForum::getSettings('punbb');

        $query = "SELECT id,username,password FROM #__users WHERE username = ".$db->Quote($instance->get('username'));
        $db->setQuery($query);
        $punUserData = $db->loadObject();

        $punCookiePrefix = $params->get('cookie_prefix');
		$punCookieName = $params->get('cookie_name');
        $punCookieDomain = $params->get('cookie_domain');
        $punCookiePath = $params->get('cookie_path');
        $punCookieSecure = $params->get('cookie_secure');
        $punCookieSeed = $params->get('cookie_seed');
        $punCookieContent = serialize(array($punUserData->id, md5($punCookieSeed.$punUserData->password)));
        
        $bypost = 1;

        //TODO: This should determine if the user is logged on from a cookie
        //		$vbUserCookie = trim(mosGetParam($_POST, 'cookieuser', '' ) );

		setcookie($punCookiePrefix.$punCookieName, $punCookieContent, time() + 43200, $punCookiePath, $punCookieDomain, $punCookieSecure);

        //TODO: Validate how we pick up the "Rember Me thing"
        if (isset($options['remember']) OR isset($session->user)) {
            $lifetime = time() + 365*24*60*60;
            setcookie("usercookie[username]", $punUserData->username, $lifetime, "/" );
            setcookie("usercookie[password]", $punUserData->password, $lifetime, "/" );
            setcookie($punCookiePrefix.$punCookieName, $punCookieContent, $lifetime, $punCookiePath, $punCookieDomain, $punCookieSecure);
            setcookie("userid", $session->userid, $lifetime, "/" );
        }
    }
    
    function getAvatar($userid)
    {
        if ($userid)
        {
                $params = AbstractForum::getSettings('punbb');
                $avatarfile = $params->get('source_url') . 'img/avatars/' . $userid . '.';
                if (file_exists($avatarfile . 'gif') {
                    $url = $params->get('source_url').'img/avatars/' . $userid . '.gif';
                } elseif (file_exists($avatarfile . 'jpg') {
                    $url = $params->get('source_url').'img/avatars/' . $userid . '.jpg';
                } else {
                    $url = $params->get('source_url').'img/avatars/' . $userid . '.png';
                }
                return $url;

            } else {

        return 0;
        }
    }
    
    

    function getRegistrationURL()
    {
       return AbstractForum::createURL('register.php', 'punbb');
    }

    function getLostPasswordURL()
    {
       return AbstractForum::createURL('login.php?action=forget', 'punbb');
    }

    function getLostUsernameURL()
    {
       return AbstractForum::createURL('login.php?action=forget', 'punbb');
    }
    
    function getThreadURL($threadid, $subject)
    {
        return  AbstractForum::createURL('viewtopic.php?id=' . $threadid, 'punbb');

    }
    
    function getPostURL($threadid, $postid, $subject)
    {
        return  AbstractForum::createURL('viewtopic.php?id=' . $threadid . '#p' . $postid, 'punbb');
    }
    
    function getProfileURL($uid,$uname)
    {
        return  AbstractForum::createURL('profile.php?id='.$uid, 'punbb');
    }

    function getQuery($usedforums, $result_order, $result_limit)
    {
if ($usedforums) {
$where = ' WHERE a.forumid IN (' . $usedforums .')';
} else {
$where = '';
}

$query = array ( 0 => array( 0 => ""/*"SELECT a.id , b.poster, b.poster_id, a.subject, b.posted, left(b.message, $result_limit) FROM `#__topics` as a INNER JOIN `#__posts` as b ON a.firstpostid = b.id " . $where . " ORDER BY a.last_post  ".$result_order." LIMIT 0,".$result_limit.";"*/,
                             1 => "SELECT a.id , b.poster, b.poster_id, a.subject, b.posted, left(b.message, $result_limit) FROM `#__topics` as a INNER JOIN `#__posts` as b ON a.last_post_id = b.id " . $where . " ORDER BY a.last_post  ".$result_order." LIMIT 0,".$result_limit.";"),
                 1 => array( 0 => ""/*"SELECT a.id , b.poster, b.poster_id, a.subject, b.posted, left(b.message, $result_limit) FROM `#__topics` as a INNER JOIN `#__posts` as b ON a.firstpostid = b.id " . $where . " ORDER BY a.posted  ".$result_order." LIMIT 0,".$result_limit.";"*/,
                             1 => "SELECT a.id , b.poster, b.poster_id, a.subject, b.posted, left(b.message, $result_limit) FROM `#__topics` as a INNER JOIN `#__posts` as b ON a.last_post_id = b.id " . $where . " ORDER BY a.posted  ".$result_order." LIMIT 0,".$result_limit.";"),
                 2 => array( 0 => "SELECT a.id , a.username, a.poster, b.subject, a.posted, a.message, a.topic_id FROM `#__posts` as a INNER JOIN `#__topics` as b ON a.topic_id = b.id " . $where . " ORDER BY a.posted ".$result_order." LIMIT 0,".$result_limit.";",
                             1 => "SELECT a.id , a.username, a.poster, b.subject, a.posted, a.message, a.topic_id FROM `#__posts` as a INNER JOIN `#__topics` as b ON a.topic_id = b.id " . $where . " ORDER BY a.posted ".$result_order." LIMIT 0,".$result_limit.";")
                 );


return $query;

    }




    function getForumUsers() {
    //getting the connection to the db
	$db = abstractForum::getDatabase('punbb');
    $query = 'SELECT username, email from #__users';
    $db->setQuery( $query );

	//getting the results
    $rows = $db->loadObjectList();

	//parse it into an array for later comparison
	foreach ( $rows as $record ) {
    $userlist[$record->username] = $record->email;
    }

    return $userlist;

	}
	
	        function filterUsername($username) {
    //no username filtering implemented yet
    return $username;

    }
    
        function getForumList()
    {
        //get the connection to the db

        $db = abstractForum::getDatabase('punbb');
        $query = 'SELECT id, forum_name as name FROM #__forums
            ORDER BY forumid';
        $db->setQuery($query );

        //getting the results
        return $db->loadObjectList();
    }

}
?>
