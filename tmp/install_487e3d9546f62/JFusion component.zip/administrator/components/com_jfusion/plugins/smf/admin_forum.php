<?php

/**
* JFusion plugin for SMF 1.1.x
*
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

//load the JFusion framework
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');




class CustomForum extends AbstractForum{

    function &getUser($username)
    {
        $instance = new JUser();
        $params = AbstractForum::getSettings('smf');

        // Get a database object
        $db = AbstractForum::getDatabase('smf');

         $query = 'SELECT ID_MEMBER as userid, memberName as username, realName as name, emailAddress as email, passwd as password, passwordSalt as password_salt FROM #__members WHERE memberName=' . $db->Quote($username) ;

        $db->setQuery($query );
        $result = $db->loadObject();

        if ($result) {
            //Check to see if they are banned
            $query = "SELECT ID_MEMBER FROM #__ban_items WHERE ID_MEMBER= " . $result->ID_MEMBER;
            $db->setQuery($query);
            if ($db->loadObject()) {
                $result->block = 1;
            } else {
                $result->block = 0;
            }
            }

        return $result;

        }
    


            /**
* Returns the name of the forum that is being integrated with.
*/
    function getJname()
    {
        return "smf";
    }


        /**
* Returns the user table name without the prefix
*/
    function getTablename()
    {
    return 'members';
    }
    
        function setupFromPath($forumPath)
    {
       //check for trailing slash and generate file path
        if (substr($forumPath, -1) == '/') {
            $myfile = $forumPath . "Settings.php";
        } else {
            $myfile = $forumPath . "/Settings.php";
        }

        //try to open the file
        if(($file_handle = @fopen($myfile, 'r')) === FALSE){
            JError::raiseWarning(500,JText::_('WIZARD_FAILURE'). ": $myfile " . JText::_('WIZARD_MANUAL'));

            //get the default parameters object
            $params = AbstractForum::getSettings($this->getJname());
            return $params;

        } else {
            //parse the file line by line to get only the config variables
            $file_handle = fopen($myfile, 'r');
            while (!feof($file_handle)) {
                $line = fgets($file_handle);
                if (strpos($line, '$') === 0) {
                    $vars = split ("'", $line);
                    $name = trim($vars[0], ' $=');
                    $value = trim($vars[1], ' $=');
                    $config[$name] = $value;

                }
            }
            fclose($file_handle);

            //load the params from the component and add in the ones from the SMF config file
            $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/smf/jfusion.xml';
            $params = new JParameter($params, $file );

            $params->set('database_host', $config['db_server'] );
            $params->set('database_type', 'mysql' );
            $params->set('database_name', $config['db_name'] );
            $params->set('database_user', $config['db_user'] );
            $params->set('database_password', $config['db_passwd'] );
            $params->set('database_prefix', $config['db_prefix'] );
            $params->set('source_url', $config['boardurl']);
            $params->set('cookie_name', $config['cookiename']);

            JError::raiseNotice(0,JText::_('WIZARD_SUCCESS'));
            return $params;
        }
    }


    function destroyForumCookie()
    {
             //TODO implement Cookie management
    }

    function createForumCookie($instance, $options, $session, $user)
    {

        //set some variables
        //$user = $user['username'];

        // Get a database object
        //$db = AbstractForum::getDatabase('smf');
        //$query = 'SELECT ID_MEMBER, passwordSalt  FROM #__members WHERE memberName=' . $db->Quote($user) ;
        //$db->setQuery($query );
        //$result = $db->loadObject();
        //$password = sha1(sha1(strtolower($user['username']) . $user['password']) . $result->passwordSalt);
        
        //set some variables
        //$params = AbstractForum::getSettings('smf');
        //$cookieName = $params->get('cookie_name');
        //$cookie_length = 60;
        //$id = $result->ID_MEMBER;
        //$salt = $result->passwordSalt;
        
        
        
        
//if ($result) {
//$passwrd = sha1(sha1(strtolower($user) . $user['password']) . $salt);
//if (isset($_COOKIE[$cookieName]))
//{
//setcookie($cookieName, '', time() - 3600, '/', '', 0);
//}


// Get the data and path to set it on.
//$data = serialize(empty($id) ? array(0, '', 0) : array($id, $user['password'], time() + $cookie_length));


// Set the cookie, $_COOKIE, and session variable.
//setcookie($cookieName, $data, time() + $cookie_length, '/','', 0);
//$_COOKIE[$cookieName] = $data;
//$_SESSION['login_',$cookieName] = $data;


//return true;

//}

    }
    

    function getRegistrationURL()
    {
        return AbstractForum::createURL('index.php?action=register', 'smf');
    }

    function getLostPasswordURL()
    {
        return AbstractForum::createURL('index.php?action=reminder', 'smf');
    }
    
    function getLostUsernameURL()
    {
        return AbstractForum::createURL('index.php?action=reminder', 'smf');
    }

    function getThreadURL($threadid, $subject)
    {
        return  AbstractForum::createURL('index.php?topic=' . $threadid, 'smf');

    }

    function getPostURL($threadid, $postid, $subject)
    {
        return  AbstractForum::createURL('index.php?topic=' . $threadid . 'msg'.$postid.'#msg' . $postid, 'smf');
    }

    function getProfileURL($uid,$uname)
    {
        return  AbstractForum::createURL('member.php?u='.$uid, 'smf');
    }



        function getQuery($usedforums, $result_order, $result_limit)
    {
if ($usedforums) {
$where = ' WHERE a.ID_BOARD IN (' . $usedforums .')';
} else {
$where = '';
}

$query = array ( 0 => array( 0 => "SELECT a.ID_TOPIC , c.posterName, c.ID_MEMBER, c.subject, c.posterTime, left(c.body, $result_limit) FROM `#__topics` as a INNER JOIN `#__messages` as b ON a.ID_LAST_MSG = b.ID_MSG INNER JOIN `#__messages` as c ON a.ID_FIRST_MSG = c.ID_MSG " . $where . " ORDER BY b.posterTime  ".$result_order." LIMIT 0,".$result_limit.";" ,
                             1 => "SELECT a.ID_TOPIC , b.posterName, b.ID_MEMBER, b.subject, b.posterTime, left(b.body, $result_limit) FROM `#__topics` as a INNER JOIN `#__messages` as b ON a.ID_LAST_MSG = b.ID_MSG " . $where . " ORDER BY b.posterTime  ".$result_order." LIMIT 0,".$result_limit.";"  ),
                 1 => array( 0 => "SELECT a.ID_TOPIC , b.posterName, b.ID_MEMBER, b.subject, b.posterTime, left(b.body, $result_limit) FROM `#__topics` as a INNER JOIN `#__messages` as b ON a.ID_FIRST_MSG = b.ID_MSG " . $where . " ORDER BY b.posterTime  ".$result_order." LIMIT 0,".$result_limit.";",
                             1 => "SELECT a.ID_TOPIC , c.posterName, c.ID_MEMBER, c.subject, c.posterTime, left(c.body, $result_limit) FROM `#__topics` as a INNER JOIN `#__messages` as b ON a.ID_FIRST_MSG = b.ID_MSG INNER JOIN `#__messages` as c ON a.ID_LAST_MSG = c.ID_MSG " . $where . " ORDER BY b.posterTime  ".$result_order." LIMIT 0,".$result_limit.";"),
                 2 => array( 0 => "SELECT a.ID_MSG , a.posterName, a.ID_MEMBER, a.subject, a.posterTime, left(a.body, $result_limit), a.ID_TOPIC  FROM `#__messages` as a " . $where . " ORDER BY a.posterTime ".$result_order." LIMIT 0,".$result_limit.";" ,
                             1 => "SELECT a.ID_MSG , a.posterName, a.ID_MEMBER, a.subject, a.posterTime, left(a.body, $result_limit), a.ID_TOPIC  FROM `#__messages` as a " . $where . " ORDER BY a.posterTime ".$result_order." LIMIT 0,".$result_limit.";")
                 );
                 
return $query;

    }






	function getForumUsers() {
    //getting the connection to the db
	$db = abstractForum::getDatabase('smf');
    $query = 'SELECT memberName, emailAddress from #__members';
    $db->setQuery( $query );

	//getting the results
    $rows = $db->loadObjectList();

	//parse it into an array for later comparison
	foreach ( $rows as $record ) {
    $userlist[$record->memberName] = $record->emailAddress;
    }

    return $userlist;
	
	}
	
        function filterUsername($username) {
    //no username filtering implemented yet
    return $username;

    }
    
       function getForumList()
    {
        //get the connection to the db

        $db = abstractForum::getDatabase('smf');
        $query = 'SELECT ID_BOARD as id, name FROM #__boards';
        $db->setQuery($query );

        //getting the results
        return $db->loadObjectList();
    }


        function getPrivateMessageCounts($userid)
    {

        if ($userid)
        {

            // read pm counts
            $db = AbstractForum::getDatabase('phpbb3');

            // read unread count
            $db->setQuery('SELECT unreadMessages FROM #__members WHERE ID_MEMBER = '.$userid);
            $unreadCount = $db->loadResult();

            // read total pm count
            $db->setQuery('SELECT instantMessages FROM #__members WHERE ID_MEMBER = '.$userid);
            $totalCount = $db->loadResult();

            return array('unread' => $unreadCount, 'total' => $totalCount);
        }
        return array('unread' => 0, 'total' => 0);
    }


        function getPrivateMessageURL()
    {
        return AbstractForum::createURL('index.php?action=pm', 'vbulletin');
    }

    function getViewNewMessagesURL()
    {
        return AbstractForum::createURL('index.php?action=unread', 'vbulletin');
    }


    function getAvatar($puser_id)
    {


        return 0;

    }
    
    
    

}
?>
