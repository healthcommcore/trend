<?php

/**
* smf password encryption method
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

class smf_auth extends AuthFactory {

    function generateEncryptedPassword($userinfo)
    {
        $testcrypt = sha1(strtolower($userinfo->username) . $userinfo->password_clear) ;
        return $testcrypt;

    }



}
