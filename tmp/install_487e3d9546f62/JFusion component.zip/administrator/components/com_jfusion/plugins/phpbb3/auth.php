<?php

/**
* phpbb3 password encryption method
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

class phpbb3_auth extends AuthFactory {

    function generateEncryptedPassword($userinfo)
    {
        //update by marius. Used the $userinfo string that included the cleartext password
        //this will allow for faster performance and allow this function to be used by other JFusion plugins

        // get the encryption PHP file
        require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/phpbb3/PasswordHash.php');

        $t_hasher = new PasswordHash(8, TRUE);
        $check = $t_hasher->CheckPassword($userinfo->password_clear, $userinfo->password);
        //$check will be true or false if the passwords match
        unset($t_hasher);
        //cleanup

        if ($check) {
            return $userinfo->password;
        } else {
            //perform a phpbb2 check
            $encrypt_password = md5($userinfo->password_clear);
            return $encrypt_password;
        }
    }



}
