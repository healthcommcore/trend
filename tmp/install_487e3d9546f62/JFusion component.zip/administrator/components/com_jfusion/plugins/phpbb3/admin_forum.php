<?php

/**
 * JFusion plugin for phpBB3
 */

//Modification for cookie control by bellzebu

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

define('SUPER_ADMIN', 'Super Administrator');
define('ADMIN', 'Administrator');
define('ANONYMOUS_ID', 1);

//load the JFusion framework
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');

class CustomForum extends AbstractForum{

    function &getUser($username)
    {
        // Get a database object
        $db = AbstractForum::getDatabase('phpbb3');

        $query = 'SELECT user_id as userid, username as name, username_clean as username, user_email as email, user_password as password FROM #__users '.
            'WHERE username_clean=' . $db->Quote($username);
        $db->setQuery($query);
        $result = $db->loadObject();

        if ($result) {
            //Check to see if they are banned
            $query = 'SELECT userid FROM `#__banlist` WHERE userid='.$result->userid;
            $db->setQuery($query);
            if ($db->loadObject()) {
                $result->block = 1;
            } else {
                $result->block = 0;
            }
        }
        // baltie - return result regardless of whether a user was found.. php doesn't like 
        // to return false by reference 
        return $result;
    }





    /**
     * Returns the name of the forum that is being integrated with.
     */
    function getJname()
    {
        return "phpbb3";
    }


    /**
     * Returns the user table name without the prefix
     */
    function getTablename()
    {
        return 'users';
    }


    function setupFromPath($forumPath)
    {
        //check for trailing slash and generate file path
        if (substr($forumPath, -1) == '/') {
            $myfile = $forumPath . "config.php";
        } else {
            $myfile = $forumPath . "/config.php";
        }

        if (($file_handle = @fopen($myfile, 'r')) === FALSE) {
            JError::raiseWarning(500,JText::_('WIZARD_FAILURE'). ": $myfile " . JText::_('WIZARD_MANUAL'));

            //get the default parameters object
            $params = AbstractForum::getSettings('phpbb3');
            return $params;

        } else {
            //parse the file line by line to get only the config variables
            $file_handle = fopen($myfile, 'r');
            while (!feof($file_handle)) {
                $line = fgets($file_handle);
                if (strpos($line, '$') === 0) {
                    //extract the name and value, it was coded to avoid the use of eval() function
                    $vars = split ("'", $line);
                    $name = trim($vars[0], ' $=');
                    $value = trim($vars[1], ' $=');
                    $config[$name] = $value;
                }
            }
            fclose($file_handle);

            //load the params from the component and add in the ones from the PHPBB config file
            $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/phpbb3/jfusion.xml';
            $params = new JParameter('', $file );

            $params->set('database_host', $config['dbhost'] );
            $params->set('database_name', $config['dbname'] );
            $params->set('database_user', $config['dbuser'] );
            $params->set('database_password', $config['dbpasswd'] );
            $params->set('database_prefix', $config['table_prefix'] );
            $params->set('database_type', $config['dbms'] );

            //create a connection to the database
            $options = array('driver' => $config['dbms'], 'host' => $config['dbhost'], 'user' => $config['dbuser'], 'password' => $config['dbpasswd'], 'database' => $config['dbname'], 'prefix' => $config['table_prefix'] );


            //Get configuration settings stored in the database
            $vdb =& JDatabase::getInstance($options);
            $query = "SELECT config_name, config_value FROM #__config WHERE config_name IN ('script_path', 'cookie_path', 'server_name', 'cookie_domain', 'cookie_name', 'allow_autologin');";
            $vdb->setQuery($query);
            if (JError::isError($vdb) ) {
                JError::raiseWarning(0, JText::_('NO_DATABASE'));
            } else {
                $rows = $vdb->loadObjectList();
                foreach($rows as $row ) {
                    $config[$row->config_name] = $row->config_value;
                }
                //store the new found parameters
                $params->set('cookie_path',  $config['cookie_path']);
                $params->set('cookie_domain',  $config['cookie_domain']);
                $params->set('cookie_prefix',  $config['cookie_name']);
                $params->set('allow_autologin',  $config['allow_autologin']);


                //check for trailing slash
                if (substr($config['server_name'], -1) == '/') {
                    $params->set('source_url', $config['server_name'] . $config['script_path'] );
                } else {
                    $params->set('source_url', $config['server_name'] . '/' . $config['script_path'] );
                };

            }
            //return the parameters so it can be saved permanently
            JError::raiseNotice(0,JText::_('WIZARD_SUCCESS'));
            return $params;
        }
    }

    function destroyForumCookie()
    {
        $userid = 0;
        $sessionid = 0;

        //get the cookie parameters
        $params = AbstractForum::getSettings('phpbb3');
        $phpbb_cookie_name = $params->get('cookie_prefix');
        $phpbb_cookie_path = $params->get('cookie_path');

        //baltie cookie domain fix
        $phpbb_cookie_domain = $params->get('cookie_domain');
        if ($phpbb_cookie_domain == 'localhost' || $phpbb_cookie_domain == '127.0.0.1') {
            $phpbb_cookie_domain = '';
        }

        if (isset($_COOKIE[$phpbb_cookie_name . '_u']) && isset($_COOKIE[$phpbb_cookie_name . '_sid'])) {
            $userid = intval($_COOKIE[$phpbb_cookie_name.'_u']);
            // baltie - removed intval since phpbb_sessions.sessionid is not an int
            $sessionid = $_COOKIE[$phpbb_cookie_name.'_sid'];
        }

        if ($userid > 0 && $sessionid) {
            $db = AbstractForum::getDatabase('phpbb3');
             
            //update session time for the user into user table
            $query = "UPDATE #__users SET user_lastvisit =" . time() . " WHERE user_id =" . $userid;
            $db->setQuery($query);
             
            // delete session data in db and cookies
            $query = "DELETE FROM #__sessions WHERE session_user_id =" . $userid . " AND session_id=" . $db->Quote($sessionid);
            $db->setQuery($query);
            if ($db->query()){
                setcookie($phpbb_cookie_name . '_u', '', time()-3600, $phpbb_cookie_path, $phpbb_cookie_domain);
                setcookie($phpbb_cookie_name . '_sid', '', time()-3600, $phpbb_cookie_path, $phpbb_cookie_domain);
            }

            // delete remember me cookie and session keys
            if (isset($_COOKIE[$phpbb_cookie_name . '_k'])) {
                $query = "DELETE FROM #__sessions_keys WHERE user_id =" . $userid . " AND session_id=" . $db->Quote($sessionid);
                $db->setQuery($query);
                if($db->query()){
                    setcookie($phpbb_cookie_name . '_k', '', time()-3600, $phpbb_cookie_path, $phpbb_cookie_domain);
                }
            }
        }
    }

    function createForumCookie($instance, $options, $session)
    {
        $db = AbstractForum::getDatabase('phpbb3');

           $userLookup = AbstractForum::lookupUserId('phpbb3', $instance->get('id'));
            if ($userLookup) {
                $userid = $userLookup->plugin_user_id;
            } else {
                //get user id
                $query = "SELECT user_id FROM #__users WHERE username_clean = " . $db->Quote($instance->get('username'));
                $db->setQuery($query);
                $userid = $db->loadResult();
            }

        if ($userid && !empty($userid) && ($userid > 0)){
            $session_key = dechex(mt_rand()) . dechex(mt_rand());

            //Check for admin access
            //$admin_access = (strcmp($instance->get('usertype'), SUPER_ADMIN) ||  strcmp($instance->get('usertype'), ADMIN)) ? 1 : 0;
            $admin_access = 0;

            $params = AbstractForum::getSettings('phpbb3');
            $phpbb_cookie_name = $params->get('cookie_prefix');

            if ($phpbb_cookie_name) {

                //get cookie domain from config table
                $phpbb_cookie_domain = $params->get('cookie_domain');
                if ($phpbb_cookie_domain == 'localhost' || $phpbb_cookie_domain == '127.0.0.1') {
                    $phpbb_cookie_domain = '';
                }

                //get cookie path from config table
                $phpbb_cookie_path = $params->get('cookie_path');

                //get autologin perm
                $phpbb_allow_autologin = $params->get('allow_autologin');

                $autologin = 0;
                if(isset($options['remember'])){
                    $jautologin = $options['remember'] ? 1 : 0;
                }

                if ($jautologin>0 && $phpbb_allow_autologin>0) {
                    $autologin = $phpbb_allow_autologin;
                }

                $session_start = time();

                //Insert the session into sessions table
                $query = "INSERT INTO #__sessions (`session_id`, `session_user_id`,
							`session_start`, `session_time`, `session_ip`, `session_browser`, `session_page`,
							`session_autologin`, `session_admin`)
							VALUES('" . substr($session_key, 0, 32) . "',".$userid.", " . $session_start . ",
							".$session_start.", '".$_SERVER['REMOTE_ADDR']."', '".$_SERVER['HTTP_USER_AGENT']."', 0," . $autologin .", ".$admin_access.")";

                $db->setQuery($query);

                if ($db->query()) {
                    //Set cookies
                    setcookie($phpbb_cookie_name . '_u', $userid, time()+(86400*365), $phpbb_cookie_path, $phpbb_cookie_domain);
                    setcookie($phpbb_cookie_name . '_sid', $session_key, time()+(86400*365), $phpbb_cookie_path, $phpbb_cookie_domain);

                    // Remember me option?
                    if ($autologin>0) {
                        //Insert the session into sessions table
                        $query = "INSERT INTO #__sessions_keys (`key_id`, `user_id`,
									`last_ip`, `last_login`)
									VALUES('" . substr($session_key, 0, 32) . "', ".$userid.", '" . $_SERVER['REMOTE_ADDR'] . "',
									".$session_start.")";

                        $db->setQuery($query);

                        if ($db->query()) {
                            setcookie($phpbb_cookie_name . '_k', $session_key, time()+(86400*365), $phpbb_cookie_path, $phpbb_cookie_domain);
                        }
                    }
                }
            }
        }
    }

    function getRegistrationURL()
    {
        return AbstractForum::createURL('ucp.php?mode=register', 'phpbb3');
    }

    function getLostPasswordURL()
    {
        return AbstractForum::createURL('ucp.php?mode=sendpassword', 'phpbb3');
    }

    function getLostUsernameURL()
    {
        return AbstractForum::createURL('ucp.php?mode=sendpassword', 'phpbb3');
    }

    function getThreadURL($threadid)
    {
        return  AbstractForum::createURL('viewtopic.php?t=' . $threadid, 'phpbb3');
    }

    function getPostURL($threadid, $postid)
    {
        return AbstractForum::createURL('viewtopic.php?p='.$postid.'#p' . $postid, 'phpbb3');
    }

    function getProfileURL($uid)
    {
        return AbstractForum::createURL('memberlist.php?mode=viewprofile&u='.$uid, 'phpbb3');
    }

    function getPrivateMessageURL()
    {
        return AbstractForum::createURL('ucp.php?i=pm&folder=inbox', 'phpbb3');
    }

    function getViewNewMessagesURL()
    {
        return AbstractForum::createURL('search.php?search_id=newposts', 'phpbb3');
    }


    function getAvatar($puser_id)
    {
        if ($puser_id)
        {
            // Okay, this can be made easier by using the download/file.php
            // script like phpbb does, rather than determine the avatar url..
            // But the overhead would be much more severe, as well as make
            // a dependency on phpbb scrips..
            // - baltie
            
            // user avatars by default are blocked to direct URL access on my server (and I assume other people as well)
            // therefore I went to use the download/file.php method instead, as this problem leads to no avatars being shown.
            // also this method will also prevent the cacheing of the avatar, resulting in avatars not
            // updating in the users browser. Sorry for deleting your hard work, I am open for discussions
            // if there is a common ground on this issue.
            $params = AbstractForum::getSettings('phpbb3');
            $db = AbstractForum::getDatabase('phpbb3');
            
            $db->setQuery("SELECT user_avatar, user_avatar_type FROM #__users WHERE user_id=".$puser_id);
            $db->query();
            $result = $db->loadObject();

            if (!empty($result))
            {
                if ($result->user_avatar_type == 1) {
                    // AVATAR_UPLOAD
                    $url = $params->get('source_url').'download/file.php?avatar='.$result->user_avatar;
                } else if ($result->user_avatar_type == 3) {
                    // AVATAR_GALLERY
                    $db->setQuery("SELECT config_value FROM #__config WHERE config_name='avatar_gallery_path'");
                    $db->query();
                    $path = $db->loadResult();
                    if (!empty($path)) {
                        $url = $params->get('source_url').$path.'/'.$result->user_avatar;
                    } else {
                        $url = '';
                    }
                } else {
                    $url = '';
                }
                return $url;
            }
        }
        return 0;
    }

    function getPrivateMessageCounts($puser_id)
    {

        if ($puser_id)
        {
            // read the counts directly from the privmsgs_to table instead of the users
            // table to be certain we have the most up-to-date values.. the values in the
            // users table is refreshed on requests to phpbb, so we cannot rely on those
            // values when only joomla is run
             
            // read pm counts
            $db = AbstractForum::getDatabase('phpbb3');
             
            // read unread count
            $db->setQuery('SELECT COUNT(msg_id)
				FROM #__privmsgs_to 
				WHERE pm_unread = 1
					AND folder_id <> -2
					AND user_id = '.$puser_id);
            $unreadCount = $db->loadResult();

            // read total pm count
            $db->setQuery('SELECT COUNT(msg_id)
				FROM #__privmsgs_to
				WHERE folder_id NOT IN (-1, -2)
					AND user_id = '.$puser_id);
            $totalCount = $db->loadResult();

            return array('unread' => $unreadCount, 'total' => $totalCount);
        }
        return array('unread' => 0, 'total' => 0);
    }

    function getQuery($usedforums, $result_order, $result_limit, $display_limit)
    {

        //set a WHERE query if a forum list was passed through
        if ($usedforums) {
            $where = ' WHERE a.forum_id IN (' . $usedforums .')';
        } else {
            $where = '';
        }

        $query = array ( 
            0 => array( 
                0 => "SELECT a.topic_id , a.topic_first_poster_name, a.topic_poster, a.topic_title, a.topic_time, left(b.post_text,$display_limit), a.forum_id as forum_specific_id FROM `#__topics` as a INNER JOIN `#__posts`  as b ON a.topic_first_post_id = b.post_id " . $where . " ORDER BY a.topic_last_post_time ".$result_order." LIMIT 0,".$result_limit.";",
                1 => "SELECT a.topic_id , a.topic_last_poster_name, a.topic_last_poster_id, a.topic_last_post_subject, a.topic_last_post_time, left(b.post_text,$display_limit), a.forum_id as forum_specific_id FROM `#__topics` as a INNER JOIN `#__posts` as b ON a.topic_last_post_id = b.post_id " . $where . " ORDER BY a.topic_last_post_time ".$result_order." LIMIT 0,".$result_limit.";"),
            1 => array( 
                0 => "SELECT a.topic_id , a.topic_first_poster_name, a.topic_poster, a.topic_title, a.topic_time, left(b.post_text,$display_limit), a.forum_id as forum_specific_id FROM `#__topics` as a INNER JOIN `#__posts`  as b ON a.topic_first_post_id = b.post_id " . $where . " ORDER BY a.topic_time ".$result_order." LIMIT 0,".$result_limit.";",
                1 => "SELECT a.topic_id , a.topic_last_poster_name, a.topic_last_poster_id, a.topic_last_post_subject, a.topic_last_post_time, left(b.post_text,$display_limit), a.forum_id as forum_specific_id FROM `#__topics` as a INNER JOIN `#__posts` as b ON a.topic_last_post_id = b.post_id " . $where . " ORDER BY a.topic_time ".$result_order." LIMIT 0,".$result_limit.";"),
            2 => array( 
                0 => "SELECT a.post_id , b.username, a.poster_id, a.post_subject, a.post_time, left(a.post_text, $display_limit), a.topic_id  FROM `#__posts` as a INNER JOIN #__users as b ON a.poster_id = b.user_id " . $where . " ORDER BY a.post_time ".$result_order." LIMIT 0,".$result_limit.";",
                1 => "SELECT a.post_id , b.username, a.poster_id, a.post_subject, a.post_time, left(a.post_text, $display_limit), a.topic_id  FROM `#__posts` as a INNER JOIN #__users as b ON a.poster_id = b.user_id " . $where . " ORDER BY a.post_time ".$result_order." LIMIT 0,".$result_limit.";")
        );
        return $query;
    }
    
    function getForumList()
    {
        //get the connection to the db

        $db = abstractForum::getDatabase('phpbb3');
        $query = 'SELECT forum_id as id, forum_name as name FROM #__forums
            WHERE forum_type = 1
            ORDER BY left_id';
        $db->setQuery($query );

        //getting the results
        return $db->loadObjectList();
    }

    function getForumUsers() {
        //getting the connection to the db
        $db = abstractForum::getDatabase('phpbb3');
        $query = 'SELECT username_clean, user_email from #__users';
        $db->setQuery( $query );

        //getting the results
        $rows = $db->loadObjectList();

        //parse it into an array for later comparison
        foreach ( $rows as $record ) {
            $userlist[$record->username_clean] = $record->user_email;
        }

        return $userlist;
    }

    function filterUsername($username) {
        // baltie - added a function exists check.. this function will already have been
        // defined if we're coming from phpbb, which is bad for my phpbb auth plugin ;)
        if (!function_exists('utf8_clean_string'))
        {
            //load the filtering functions for phpBB3
            require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/phpbb3/username_clean.php');
        }

        $username_clean = utf8_clean_string($username);
        return $username_clean;
    }
}
?>
