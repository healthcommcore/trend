<?php

/**
* ipb password encryption method
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

class ipb_auth extends AuthFactory {

    /**
     * Generate IPB encrypted password from user-supplied login and password
     *
     * @param array $credentials Joomla & JFusion user data
     * @return string Returns generated password
     */
    function generateEncryptedPassword($userinfo)
    {
        $testcrypt = md5(md5($userinfo->password_salt) . md5($userinfo->password_clear));
        return $testcrypt;
    }



}
