<?php

/**
 * JFusion plugin for IPB
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

// Load the JFusion framework
require_once(JPATH_ADMINISTRATOR . '/components/com_jfusion/admin.abstract_forum.php');

/**
 * Class to handle IPB actions
 */
class CustomForum extends AbstractForum
{

    //removed the db and param initialisation, as this caused the JFusion wizard to crash
    //this was due to the db and params object being loaded without the plugin being configured
    
    /**
     * Fetch user data from IPB table
     *
     * @param array $user JFusion user data
     * @param array $options Addition options
     * @return mixed Return an object of type JUser on success, or boolean false on failure
     */
    function &getUser($username)
    {
        // Get a database object
        $db = AbstractForum::getDatabase('ipb');

        // Get user info from database
        $query = 'SELECT b.id as userid, b.name as username, email as email, members_display_name as name, temp_ban as block, converge_pass_hash as password, converge_pass_salt as password_salt FROM #__members_converge as a INNER JOIN #__members as b ON a.converge_email = b.email WHERE b.name = ' . $db->Quote($username);
        $db->setQuery($query);
        $result = $db->loadObject();

        return $result;


    }



    /**
     * Returns the name of the forum that is being integrated with.
     *
     * @return string
     */
    function getJname()
    {
        return 'ipb';
    }

    /**
     * Returns the user table name without the prefix
     *
     * @return string Table name
     */
    function getTablename()
    {
        return 'members_converge';
    }

    /**
     * Setup wizard
     *
     * @param string $forumPath Server path to forum
     * @return JParameter Configuration parameters
     */
    function setupFromPath($forumPath)
    {
        // Check for trailing slash and generate file path
        if (substr($forumPath, -1) == '/')
        {
            $myfile = $forumPath . 'conf_global.php';
        }
        else
        {
            $myfile = $forumPath . '/conf_global.php';
        }

        // Try to open the file
        if (($file_handle = @fopen($myfile, 'r')) === FALSE)
        {
            JError::raiseWarning(500, JText::_('WIZARD_FAILURE') . ": $myfile " . JText::_('WIZARD_MANUAL'));

            // Get the default parameters object
            $params = AbstractForum::getSettings($this->getJname());
            return $params;
        }
        else
        {
            // Parse the file line by line to get only the config variables
            $file_handle = fopen($myfile, 'r');
            while (!feof($file_handle))
            {
                $line = fgets($file_handle);
                if (strpos($line, '$') === 0)
                {
                    // Extract the name and value, it was coded to avoid the use of eval() function
                    $vars = split ("'", $line);
                    $name = trim($vars[1], ' $=');
                    $value = trim($vars[3], ' $=');
                    $config[$name] = $value;
                }
            }
            fclose($file_handle);

            // Load the params from the component and add in the ones from the ipb config file
            $file = JPATH_ADMINISTRATOR . '/components/com_jfusion/plugins/ipb/jfusion.xml';

            $params = new JParameter('', $file);
            $params->set('database_host',     $config['sql_host']);
            $params->set('database_name',     $config['sql_database']);
            $params->set('database_user',     $config['sql_user']);
            $params->set('database_password', $config['sql_pass']);
            $params->set('database_prefix',   $config['sql_tbl_prefix']);
            $params->set('database_type',     $config['sql_driver']);
            $params->set('source_url',        $config['board_url']);

            //found out some more parameters


            JError::raiseNotice(0,JText::_('WIZARD_SUCCESS'));
            return $params;
        }
    }

    /**
     * Destroy IPB cookies when logged out
     *
     * @return void
     */
    function destroyForumCookie()
    {
        // Get needed params
        //get the cookie parameters
        $params = AbstractForum::getSettings('ipb');
        $expires = time() - 60*60*24*365;
        $prefix = $params->get('cookie_prefix');
        $path   = $params->get('cookie_path', '/');
        $domain = $params->get('cookie_domain');

        // Destroy cookies
        setcookie($prefix . 'member_id', '0', $expires, $path, $domain);
        setcookie($prefix . 'pass_hash', '0', $expires, $path, $domain);
        setcookie($prefix . 'session_id', '', $expires, $path, $domain);
        if ($params->get('ipb_cookie_stronghold'))
        {
            setcookie($prefix . $params->get('ipb_cookie_stronghold'), '', $expires, $path, $domain);
        }
    }

    /**
     * Setup IPB cookies for single sign-in
     *
     * @param object $instance Joomla & JFusion user data
     * @param array $options Additional parameters
     * @param object $session JFusion session data
     */
    function createForumCookie($instance, $options, $session)
    {
        // Get a database object
        $db = AbstractForum::getDatabase('ipb');
        $params = AbstractForum::getSettings('ipb');
        
        // Get IPB member id and login key for single sign-in
        $query = 'SELECT id, member_login_key FROM #__members WHERE name = ' . $db->Quote($instance->get('username'));
        $db->setQuery($query);
        $result = $db->loadObject();

        // Set some cookie params
        if (isset($options['remember']) && $options['remember'])
        {
            $expires = time() + 60*60*24*365;
        }
        else
        {
        	$expires = false;
        }

        $prefix = $params->get('cookie_prefix');
        $path   = $params->get('cookie_path', '/');
        $domain = $params->get('cookie_domain');

        // Set basic cookies
        setcookie($prefix . 'member_id', $result->id, $expires, $path, $domain);
        setcookie($prefix . 'pass_hash', $result->member_login_key, $expires, $path, $domain);
        setcookie($prefix . 'session_id', '', $expires, $path, $domain);

        // Set strong protection cookie
        if ($params->get('ipb_cookie_stronghold'))
        {
    	    $ip = '';

    	    if (is_array($_SERVER) && count($_SERVER))
    	    {
    		    if (isset($_SERVER['REMOTE_ADDR']))
    		    {
    			    $ip = $_SERVER['REMOTE_ADDR'];
    		    }
    	    }

    	    if (!$ip)
    	    {
    		    $ip = getenv('REMOTE_ADDR');
    	    }

    	    if (!$ip)
    	    {
    	        return false;
    	    }

    		$ip_octets  = explode('.', $ip);
    		$crypt_salt = md5($params->get('database_password') . $params->get('database_user'));
    		$stronghold = md5(md5($result->id . '-' . $ip_octets[0] . '-' . $ip_octets[1] . '-' . $result->member_login_key) . $crypt_salt);

    		setcookie($prefix . $params->get('ipb_cookie_stronghold'), $stronghold, $expires, $path, $domain);
        }
    }

    /**
     * Returns the URL to registration page
     *
     * @return string URL to registration page
     */
    function getRegistrationURL()
    {
        return AbstractForum::createURL('index.php?act=Reg&CODE=00', $this->getJname());
    }

    /**
     * Returns the URL to lost password page
     *
     * @return string URL to lost password page
     */
    function getLostPasswordURL()
    {
        return AbstractForum::createURL('index.php?act=Reg&CODE=10', $this->getJname());
    }

    /**
     * Returns the URL to forgot username page
     *
     * @return string URL to forgot username page
     */
    function getLostUsernameURL()
    {
        return AbstractForum::createURL('index.php?act=Reg&CODE=10', $this->getJname());
    }

    /**
     * Returns the URL to a particular thread
     *
     * @param int $threadid Thread ID
     * @param string $subject Thread subject
     * @return string URL to that particular thread
     */
    function getThreadURL($threadid, $subject)
    {
        return AbstractForum::createURL('index.php?showtopic=' . $threadid, $this->getJname());
    }

    /**
     * Returns the URL to a particular post
     *
     * @param int $threadid Thread ID for the thread where the post resides
     * @param int $postid Post ID
     * @param string $subject Post subject
     * @return string URL to that particular post
     */
    function getPostURL($threadid, $postid, $subject)
    {
        return AbstractForum::createURL('index.php?showtopic=' . $threadid . '&view=findpost&p='.$postid, $this->getJname());
    }

    /**
     * Returns the URL to a particular user's profile
     *
     * @param int $uid User ID
     * @param string $uname User name
     * @return string URL to that particular user profile
     */
    function getProfileURL($uid, $uname)
    {
        return AbstractForum::createURL('index.php?showuser='.$uid, $this->getJname());
    }

    function getQuery($usedforums, $result_order, $result_limit, $char_limit)
    {
        if ($usedforums)
        {
            $where = ' WHERE b.forum_id IN (' . $usedforums . ')';
        }
        else
        {
            $where = '';
        }

        $query = array ( 0 => array( 0 => "SELECT a.tid, a.starter_name, a.starter_id, a.title, a.start_date, left(b.post, $char_limit) FROM #__topics as a INNER JOIN #__posts as b ON a.topic_firstpost = b.pid " . $where . " ORDER BY a.last_post ".$result_order." LIMIT 0,".$result_limit.";",
                                     1 => "SELECT a.tid, a.starter_name, a.starter_id, a.title, a.start_date, left(b.post, $char_limit) FROM #__topics as a INNER JOIN #__posts as b ON a.topic_firstpost = b.pid " . $where . " ORDER BY a.last_post ".$result_order." LIMIT 0,".$result_limit.";"),
                         1 => array( 0 => "SELECT a.tid, a.starter_name, a.starter_id, a.title, a.start_date, left(b.post, $char_limit) FROM #__topics as a INNER JOIN #__posts as b ON a.topic_firstpost = b.pid " . $where . " ORDER BY a.start_date ".$result_order." LIMIT 0,".$result_limit.";",
                                     1 => "SELECT a.tid, a.starter_name, a.starter_id, a.title, a.start_date, left(b.post, $char_limit) FROM #__topics as a INNER JOIN #__posts as b ON a.topic_firstpost = b.pid " . $where . " ORDER BY a.start_date ".$result_order." LIMIT 0,".$result_limit.";"),
                         2 => array( 0 => "SELECT b.pid, b.author_name, b.author_id, a.title, b.post_date, left(b.post, $char_limit) FROM #__topics as a INNER JOIN #__posts as b ON a.topic_firstpost = b.pid " . $where . " ORDER BY b.post_date ".$result_order." LIMIT 0,".$result_limit.";",
                                     1 => "SELECT b.pid, b.author_name, b.author_id, a.title, b.post_date, left(b.post, $char_limit) FROM #__topics as a INNER JOIN #__posts as b ON a.topic_firstpost = b.pid " . $where . " ORDER BY b.post_date ".$result_order." LIMIT 0,".$result_limit.";")
                       );

        return $query;
    }

    /**
     * Get a full list of member names and emails from IPB
     *
     * @return array A list of member names and emails, smth. like $userlist = array(
     *                                                                                'John'   => 'johnsmith@somewhere.com',
     *                                                                                'Ronnie' => 'ronaldr@everywhere.net'
     *                                                                              )
     */
    function getForumUsers()
    {

        $db = AbstractForum::getDatabase('ipb');
        $query = 'SELECT name, email from #__members';
        $db->setQuery($query);
        $rows = $db->loadObjectList();

        // Parse the data into an array for later comparison
        foreach ($rows as $record)
        {
            $userlist[$record->name] = $record->email;
        }

        return $userlist;
    }
    
        function filterUsername($username) {
    //no username filtering implemented yet
    return $username;

    }
    
    function getForumList()
    {
        //get the connection to the db

        $db = abstractForum::getDatabase('ipb');
        $query = 'SELECT id, name FROM #__forums';
        $db->setQuery($query );

        //getting the results
        return $db->loadObjectList();
    }


        function getPrivateMessageCounts($userid)
    {

        if ($userid)
        {

            // read pm counts
            $db = AbstractForum::getDatabase('ipb');

            // read unread count
            $db->setQuery('SELECT new_msg, msg_total FROM #__members WHERE id = '.$userid);
            $pminfo = $db->loadObject();


            return array('unread' => $pminfo->new_msg, 'total' => $pminfo->msg_total);
        }
        return array('unread' => 0, 'total' => 0);
    }


        function getPrivateMessageURL()
    {
        return AbstractForum::createURL('index.php?act=Msg&CODE=01', 'ipb');
    }

    function getViewNewMessagesURL()
    {
        return AbstractForum::createURL('index.php?act=Search&CODE=getnew', 'ipb');
    }


    function getAvatar($userid)
    {


        return 0;

    }
    
    
    
}

?>
