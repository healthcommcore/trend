<?php

/**
* JFusion plugin for myBB 1.2.12
*
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

//load the JFusion framework
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');



class CustomForum extends AbstractForum{

    function &getUser($username)
    {
         // Get user info from database
        $db = AbstractForum::getDatabase('mybb');
        $query = 'SELECT uid as userid, username,email, usergroup, password, salt as password_salt FROM #__users WHERE username=' . $db->Quote($username);
        $db->setQuery($query );
        $result = $db->loadObject();

        if ($result) {

           //Check to see if they are banned
            $query = 'SELECT isbannedgroup FROM `#__usergroups` WHERE gid=' . $result->usergroup;
			$db->setQuery( $query );
			$banCheck = $db->loadObject();

            if ($result->usergroup == 5 || ($banCheck && $banCheck->isbannedgroup == "yes")) {
                $result->block = 1;
            } else {
                $result->block = 0;
            }
            }
            
            return $result;

    }



            /**
* Returns the name of the forum that is being integrated with.
*/
    function getJname()
    {
        return "mybb";
    }


        /**
* Returns the user table name without the prefix
*/
    function getTablename()
    {
    return 'users';
    }
    
        function setupFromPath($forumPath)
    {
        //check for trailing slash and generate config file path
        if (substr($forumPath, -1) != '/') $forumPath .="/";
        $myfile = $forumPath . "inc/config.php";
   
        //include config file
        require_once $myfile;
        
         //load the params from the component and add in the ones from the mybb config file
         $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/mybb/jfusion.xml';
         $params = new JParameter('', $file );
         $params->set('database_type', $config['dbtype']);
         $params->set('database_host', $config['hostname']  );
         $params->set('database_user', $config['username'] );
         $params->set('database_password', $config['password'] );
         $params->set('database_name', $config['database'] );
         $params->set('database_prefix', $config['table_prefix'] );
         
         //find the source url to mybb
         $driver = $config['dbtype'];
         $host = $config['hostname'];
         $user = $config['username'];
         $password = $config['password'];
         $database = $config['database'];
         $prefix = $config['table_prefix'];
         $options = array('driver' => $driver, 'host' => $host, 'user' => $user, 'password' => $password, 'database' => $database, 'prefix' => $prefix );
         $bb =& JDatabase::getInstance($options );
         $query = "SELECT value FROM #__settings WHERE name = 'bburl'";
         $bb->setQuery($query);
         $bb_url = $bb->loadResult();
         if (substr($bb_url, -1) != '/') $bb_url .="/";
         $params->set('source_url', $bb_url);
         
         $query = "SELECT value FROM #__settings WHERE name='cookiedomain'";
         $bb->setQuery($query);
         $cookiedomain = $bb->loadResult();
         $params->set('cookie_domain', $cookiedomain);

         $query = "SELECT value FROM #__settings WHERE name='cookiepath'";
         $bb->setQuery($query);
         $cookiepath = $bb->loadResult();
         $params->set('cookie_path', $cookiepath);
         
         JError::raiseNotice(0,JText::_('WIZARD_SUCCESS'));
         return $params;
   }


    //maybe better could be member.php?action=logout&uid={$mybb->user['uid']}&sid={$session->sid}
      function destroyForumCookie()
      {
      $params = AbstractForum::getSettings('mybb');
      $cookiedomain = $params->get('cookie_domain');
      $cookiepath = $params->get('cookie_path', '/');
      
      //Set cookie values
      //$expires = time()-3600;
      $expires = mktime(12,0,0,1, 1, 1990);

      if(!$cookiepath)
      {
         $cookiepath = "/";
      }
        
   	// Clearing Forum Cookies
   	$remove_cookies = array('mybb', 'mybbuser', 'mybbadmin');
      if($cookiedomain)
      {
         foreach($remove_cookies as $name)
         {
			   @setcookie($name, '', $expires, $cookiepath, $cookiedomain);
		   }
      }
      else
	  {
         foreach($remove_cookies as $name)
         {
            @setcookie($name, '', $expires, $cookiepath);
         }
      }
   }
 

   function createForumCookie($instance,$options, $session)
   {
     //get cookiedomain, cookiepath (theIggs solution)
      $params = AbstractForum::getSettings('mybb');
      $cookiedomain = $params->get('cookie_domain','');
      $cookiepath = $params->get('cookie_path','/');
      //get myBB uid, loginkey
      $db = AbstractForum::getDatabase('mybb');
      $query = "SELECT uid, loginkey FROM #__users WHERE username='".$instance->get('username') ."'";
      $db->setQuery($query );
      $user = $db->loadObject();

      $sid = $session->session_id; //not used

      // Set cookie values
      $name="mybbuser";
      $value=$user->uid."_".$user->loginkey;
      $expires = null;
      $remember="no";
      $httponly=true;

   	// Creating Forum Cookies
   	//adopted from myBB function my_setcookie() in inc/functions.php
      if(!$cookiepath)
      {
         $cookiepath = "/";
      }
      if($expires == -1)
   	{
   		$expires = 0;
   	}
   	else if($expires == "" || $expires == null)
   	{
   		if($remember == "no")
   		{
   			$expires = 0;
   		}
   		else
   		{
   			$expires = time() + (60*60*24*365); // Make the cookie expire in a years time
   		}
   	}
   	else
   	{
   		$expires = time() + intval($expires);
   	}

   	$cookiepath = str_replace(array("\n","\r"), "", $cookiepath);
   	$cookiedomain = str_replace(array("\n","\r"), "", $cookiedomain);

   	// Versions of PHP prior to 5.2 do not support HttpOnly cookies and IE is buggy when specifying a blank domain so set the cookie manually
   	$cookie = "Set-Cookie: {$name}=".urlencode($value);
   	if($expires > 0)
   	{
   		$cookie .= "; expires=".gmdate('D, d-M-Y H:i:s \\G\\M\\T', $expires);
   	}
   	if(!empty($cookiepath))
   	{
   		$cookie .= "; path={$cookiepath}";
   	}
   	if(!empty($cookiedomain))
   	{
   		$cookie .= "; domain={$cookiedomain}";
   	}
   	if($httponly == true)
   	{
   		$cookie .= "; HttpOnly";
   	}
   	header($cookie, false);
   }

    function getRegistrationURL()
    {
       return AbstractForum::createURL('member.php?action=register', 'mybb');
    }

    function getLostPasswordURL()
    {
       return AbstractForum::createURL('member.php?action=lostpw', 'mybb');
    }

    function getLostUsernameURL()
    {
       return AbstractForum::createURL('member.php?action=lostpw', 'mybb');
    }
    
    function getThreadURL($threadid, $subject)
    {
        return  AbstractForum::createURL('showthread.php?tid='.$threadid, 'mybb');

    }
    
    function getPostURL($threadid, $postid, $subject)
    {
        return  AbstractForum::createURL('showthread.php?tid='.$threadid.'&pid='.$postid.'#pid'.$postid, 'mybb');
    }
    
    function getProfileURL($uid,$uname)
    {
        return  AbstractForum::createURL('member.php?action=profile&uid'.$uid, 'mybb');
    }


    function getQuery($usedforums, $result_order, $result_limit, $display_limit)
    {
      if ($usedforums)
      {
         $where = ' WHERE a.fid IN (' . $usedforums .')';
      } else {
         $where = '';
      }
      $query = array(0 => array( 0 => "SELECT a.tid , a.username, a.uid, a.subject, a.dateline, left(b.message, $display_limit) FROM #__threads as a INNER JOIN #__posts as b ON a.firstpost = b.pid " . $where . " ORDER BY a.lastpost ".$result_order." LIMIT 0,".$result_limit.";",
                                 1 => "SELECT a.tid , a.lasposter, a.lasposteruid, a.subject, a.laspost, left(b.message, $display_limit) FROM #__threads as a INNER JOIN #__posts as b ON a.lastpost = b.dateline " . $where . " ORDER BY a.lastpost ".$result_order." LIMIT 0,".$result_limit.";"),
                     1 => array( 0 => "SELECT a.tid , a.username, a.uid, a.subject, a.dateline, left(b.message, $display_limit) FROM #__threads as a INNER JOIN #__posts as b ON a.firstpost = b.pid " . $where . " ORDER BY a.dateline ".$result_order." LIMIT 0,".$result_limit.";",
                                 1 => "SELECT a.tid , a.lastposter, a.lasposteruid, a.subject, a.dateline, left(b.message, $display_limit) FROM #__threads as a INNER JOIN #__posts as b ON a.lastpost = b.dateline " . $where . " ORDER BY a.dateline ".$result_order." LIMIT 0,".$result_limit.";"),
                     2 => array( 0 => "SELECT a.pid , b.username, a.uid, a.subject, a.dateline, left(a.message, $display_limit), a.tid  FROM `#__posts` as a INNER JOIN #__users as b ON a.uid = b.uid " . $where . " ORDER BY a.dateline ".$result_order." LIMIT 0,".$result_limit.";",
                                 1 => "SELECT a.pid , b.username, a.uid, a.subject, a.dateline, left(a.message, $display_limit), a.tid  FROM `#__posts` as a INNER JOIN #__users as b ON a.uid = b.uid " . $where . " ORDER BY a.dateline ".$result_order." LIMIT 0,".$result_limit.";")
                 );
                 return $query;
    }

    function getForumUsers() {
    //getting the connection to the db
	$db = abstractForum::getDatabase('mybb');
    $query = 'SELECT username, email from #__users';
    $db->setQuery( $query );

	//getting the results
    $rows = $db->loadObjectList();

	//parse it into an array for later comparison
	foreach ( $rows as $record ) {
    $userlist[$record->username] = $record->email;
    }

    return $userlist;

	}
	
	        function filterUsername($username) {
    //no username filtering implemented yet
    return $username;

    }
    
        function getForumList()
    {
        //get the connection to the db

        $db = abstractForum::getDatabase('mybb');
        $query = 'SELECT fid as id, name FROM #__forums';
        $db->setQuery($query );

        //getting the results
        return $db->loadObjectList();
    }


        function getPrivateMessageCounts($userid)
    {

        if ($userid)
        {

            // read pm counts
            $db = AbstractForum::getDatabase('mybb');

            // read unread count
            $db->setQuery('SELECT totalpms, newpms FROM #__users WHERE uid = '.$userid);
            $pminfo = $db->loadObject();


            return array('unread' => $pminfo->newpms, 'total' => $pminfo->totalpms);
        }
        return array('unread' => 0, 'total' => 0);
    }


        function getPrivateMessageURL()
    {
        return AbstractForum::createURL('private.php', 'mybb');
    }

    function getViewNewMessagesURL()
    {
        return AbstractForum::createURL('search.php?action=getnew', 'mybb');
    }


    function getAvatar($userid)
    {
               // read pm counts
            $db = AbstractForum::getDatabase('mybb');

            // read unread count
            $db->setQuery('SELECT avatar FROM #__users WHERE uid = '.$userid);
            $avatar = $db->loadResult();
            
            $avatar = substr($avatar, 2);
                $params = AbstractForum::getSettings('mybb');
                $url = $params->get('source_url'). $avatar;
                return $url;
            

        return 0;

    }
    
    

}
?>
