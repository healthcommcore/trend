<?php

/**
* mybb password encryption method
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

class mybb_auth extends AuthFactory {

    function generateEncryptedPassword($userinfo)
    {
           //Apply myBB encryption
            $testcrypt = md5(md5($userinfo->password_salt).md5($userinfo->password_clear));

            return $testcrypt;
    }



}
