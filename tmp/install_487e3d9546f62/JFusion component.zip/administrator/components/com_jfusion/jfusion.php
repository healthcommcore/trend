<?php
/**
* @package com_jfusion
* @version 1.0.5
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

// require the html view class
jimport('joomla.application.helper' );
require_once(JApplicationHelper::getPath('front_html', 'com_jfusion' ) );
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.abstract_forum.php');

switch ($task) {
case 'show':
    show_url();
    break;
    default:
    show_url();
    break;
}
function show_url()
{
    //get the forum url
    $wrap = urldecode(JRequest::getVar('wrap', '', 'get'));
    //get the path to the forum
    $jname =  AbstractForum::getJname();
    $params = AbstractForum::getSettings($jname);
    $source_url = $params->get('source_url');

    //check to see if url starts with http
$test_url = substr($source_url, 0, 4);
if ($test_url == 'http') {
} else {
$source_url = 'http://' . $source_url;
}

//check for trailing slash
if (substr($source_url, -1) == '/') {
$url = $source_url . $wrap;
} else {
$url = $source_url . '/'. $wrap;
};
jfusionWrap::show_url($url);
}
?>

