<?php

/**
 * @package com_jfusion
 * @version 1.0.5
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

// no direct access
defined('_JEXEC' ) or die('Restricted access' );

/**
 * Abstract interface for all forum implementations.
 *
 */
class AbstractForum{

    /**
     * Returns the name of the JFusion integration that is currently enabled
     */

    function getJname()
    {
        //find the first forum that is enabled
        $db = & JFactory::getDBO();
        $query = 'SELECT name from #__jfusion WHERE enabled = 1';
        $db->setQuery($query );
        $jname = $db->loadResult();
        return $jname;
    }

    /**
     * Returns the parameters of a specific JFusion integration
     */

    function &getSettings($jname)
    {
        static $parametersInstance;

        if (!is_object($parametersInstance)) {
            //get the current parameters from the jfusion table
            $db = & JFactory::getDBO();
            $query = 'SELECT params from #__jfusion WHERE name = ' . "'$jname'";
            $db->setQuery($query );
            $serialized = $db->loadResult();

            //get the parameters from the XML file
            $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/plugins/'. $jname . '/jfusion.xml';

            $parametersInstance = new JParameter('', $file );

            //apply the stored valued
            if ($serialized) {
                $params = unserialize($serialized);

                foreach($params as $key => $value) {
                    $parametersInstance->set($key, $value );
                }
            }

            if (!is_object($parametersInstance)) {
                JError::raiseError(500, JText::_('NO_FORUM_PARAMETERS'));
            }
        }
        return $parametersInstance;
    }

    /**
     * Saves the posted JFusion component variables
     * returns true if succesful and false if an error occurred
     */

    function saveParameters($jname, $post)
    {

        //serialize the $post to allow storage in a SQL field
        $serialized = serialize($post);
        //set the current parameters in the jfusion table
        $db = & JFactory::getDBO();
        $query = "UPDATE #__jfusion SET params = '$serialized' WHERE name = '$jname'";
        $db->setQuery($query );
        $db->query();

        AbstractForum::checkConfig($jname);

        //TODO add error routine to catch SQL errors
        return true;
    }

    /**
     * Checks to see if the JFusion plugins are installed and enabled
     */
    function checkPlugin()
    {
    
                JError::raiseNotice(0,JText::_('FUSION_INSTALL_TIP'));
    
        $userPlugin = true;
        $authPlugin = true;
        if (!AbstractForum::isPluginInstalled('jfusion','authentication', false)) {
            JError::raiseWarning(0,JText::_('FUSION_MISSING_AUTH'));
            $authPlugin = false;
        }

        if (!AbstractForum::isPluginInstalled('jfusion','user', false)) {
            JError::raiseWarning(0,JText::_('FUSION_MISSING_USER'));
            $userPlugin = false;
        }

        if ($authPlugin && $userPlugin) {
            $jAuth = AbstractForum::isPluginInstalled('jfusion','user',true);
            $jUser = AbstractForum::isPluginInstalled('jfusion','authentication',true);
            if (!$jAuth) {
                JError::raiseNotice(0,JText::_('FUSION_READY_TO_USE_AUTH'));
            }
            if (!$jUser) {
                JError::raiseNotice(0,JText::_('FUSION_READY_TO_USE_USER'));
            }
        }
    }


    /**
     * Checks to see if the configuration of a Jfusion plugin is valid and stores the result in the JFusion table
     */

    function checkConfig($jname)
    {

        $db = AbstractForum::getDatabase($jname);
        $jdb =& JFactory::getDBO();

        if (JError::isError($db) ) {
            //Save this error for the integration
            $query = 'UPDATE #__jfusion SET status = 1 WHERE name =' . "'$jname'";
            $jdb->setQuery($query );
            $jdb->query();
        } else {
            //get the user table name
            $forum = ForumFactory::getForum($jname);
            $tablename = $forum->getTablename();

            //lets see if we can get some data
            $query = 'SELECT * FROM #__' . $tablename . ' LIMIT 1';
            $db->setQuery($query );
            $result = $db->loadObject();
            if ($result) {
                //Save this succes on check
                $query = 'UPDATE #__jfusion SET status = 3 WHERE name =' . "'$jname'";
                $jdb->setQuery($query );
                $jdb->query();
            } else {
                //Save this error for the integration
                $query = 'UPDATE #__jfusion SET status = 2 WHERE name =' . "'$jname'";
                $jdb->setQuery($query );
                $jdb->query();

            }

        }
    }


    /**
     * Returns a list of current Joomla users
     */

    function getJoomlaUsers()
    {
        //getting the connection to the db
        $db = & JFactory::getDBO();
        $query = 'SELECT u.username, jul.plugin_username, u.email FROM #__users AS u '.
            'LEFT JOIN #__jfusion_user_lookup AS jul ON u.id = jul.juser_id';
        $db->setQuery($query );

        //getting the results
        $rows = $db->loadObjectList();

        //parse it into an array for later comparison
        foreach($rows as $record ) {
            if ($record->plugin_username) {
                $userlist[$record->plugin_username] = $record->email;
            } else {
                // baltie - added username filtering
                //mariusvr - removed username filtering, as it is now handled in usersync.

                $userlist[$record->username] = $record->email;
            }
        }

        return $userlist;
    }


    /**
     * Tests if a plugin is installed with the specified name, where folder is the type (e.g. user)
     */
    function isPluginInstalled($element,$folder, $testPublished)
    {
        $jdb =& JFactory::getDBO();
        $query = "SELECT `published` FROM `#__plugins` WHERE `element`='$element' AND `folder`='$folder'";
        $jdb->setQuery($query);
        $result = $jdb->loadObject();
        if ($result) {
            if ($testPublished) {
                return($result->published == 1);
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    /**
     *  Acquires a database connection to the forum database. It is assumed that all
     *  forums have an equivalent database set-up (in that they have a host, db name, username, and password.
     *
     *  @return database
     */
    function &getDatabase($jname)
    {

        static $jfusion_database;
        if (!is_object($jfusion_database)) {
            //get the debug configuration setting
            $conf =& JFactory::getConfig();
            $debug = $conf->getValue('config.debug');


            //TODO see if we can delete these jimports below
            jimport('joomla.database.database');
            jimport('joomla.database.table' );

            //get config values
            $conf =& JFactory::getConfig();
            $params = AbstractForum::getSettings($jname);

            //prepare the data for creating a database connection
            $host = $params->get('database_host');
            $user = $params->get('database_user');
            $password = $params->get('database_password');
            $database = $params->get('database_name');
            $prefix = $params->get('database_prefix');
            $driver = $params->get('database_type');
            $debug = $conf->getValue('config.debug');

            //create an options variable that contains all database connection variables
            $options = array('driver' => $driver, 'host' => $host, 'user' => $user, 'password' => $password, 'database' => $database, 'prefix' => $prefix );

            //create the actual connection
            $jfusion_database =& JDatabase::getInstance($options );
            if (JError::isError($jfusion_database) ) {
                JError::raiseWarning(0, JText::_('NO_DATABASE'));
            }
        }
        return $jfusion_database;
    }

    /**
     *  Check the if the URL's should be wrapped in an i-frame
     *  $url variable passed should contain only the filename inside the forum path/url.
     *
     * fthisunction will return either the Joomla wrapper URL or the full URL directly to the forum
     */

    function createURL($url, $jname)
    {
        $params = AbstractForum::getMainSettings();
        //check to see if they want to use the wrapper
        if ($params->get('use_wrapper')) {
            $url_root = JURI::root();
            $url = $url_root . "index.php?option=com_jfusion&wrap=". urlencode($url);
        } else {
            $params2 = AbstractForum::getSettings($jname);
            $url = $params2->get('source_url') . $url;
        }
        return $url;

    }

    /**
     * Get the main parameters of JFusion that apply to all integrations
     */
    function &getMainSettings(){
        static $parametersInstance;

        if (!is_object($parametersInstance)) {
            $row =& JTable::getInstance('component' );
            $row->loadByOption('com_jfusion' );
            $parameters = JArrayHelper::fromObject($row );
            $params = $parameters['params'];
            $file = JPATH_ADMINISTRATOR .'/components/com_jfusion/com_jfusion.xml';
            $parametersInstance = new JParameter($params, $file );
        }
        if (!is_object($parametersInstance)) {
            JError::raiseError(500, JText::_('NO_FORUM_PARAMETERS'));
        }

        return $parametersInstance;
    }

    function saveMainParameters($post) {
        $table =& JTable::getInstance('component');
        $table->loadByOption('com_jfusion' );
        $table->bind($post );
        // pre-save checks
        if (!$table->check()) {
            JError::raiseWarning(500, $table->getError() );
            return false;
        }
        // save the changes
        if (!$table->store()) {
            JError::raiseWarning(500, $table->getError() );
            return false;
        }
        return true;
    }

    function createJoomlaUsername($jname, $userid, $username, $email, $password, $usertype, $gid, $params = NULL, $email_conflict = 1) {
        
        $db =& JFactory::getDBO();
        $instance = new JUser();
        $forum = ForumFactory::getForum($jname);

        //generate the filtered integration username
        $plugin_username = $forum->filterUsername($username);
        
                //see if we need to filter the username
        if (is_null($params))
        {
            $params = AbstractForum::getMainSettings();
        }
        if ($params->get('username_filter')) {
            $username_clean = AbstractForum::joomlaUsername($plugin_username);
        } else {
            $username_clean = $plugin_username;
        }
        
        //check for conlicting email addresses
        $db->setQuery("SELECT id FROM #__users WHERE email=".$db->Quote($email));
        $conflict_id = $db->loadResult();
        if ($conflict_id) {
           //found conflicting email address
           if ($email_conflict == 1) {
              //return an error and abort the user creation
              JError::raiseWarning(500, 'Could not create a new user because of an email conflict with userid:' . $conflict_id . ' plugin_username:' . $plugin_username . ' email:' . $email);
              return false;
           }
           if ($email_conflict == 2) {
              //delete the conflicted Joomla user and create the new user as planned
              $instance = new JUser();
              $instance->load(int($conflict_id));
              $instance->delete();
           }
           
           if ($email_conflict == 3) {
               //make sure the username is at least 3 characters long
               while (strlen($username_clean) < 3) {
                   $username_clean .= '_';
               }

               // make sure the username is unique
               $db->setQuery("SELECT id FROM #__users WHERE username=".$db->Quote($username_clean));
               while ($db->loadResult()) {
                   $username_clean .= '_';
                   $db->setQuery("SELECT id FROM #__users WHERE username=".$db->Quote($username_clean));
               }

               //update the username of the conflicting user
               $query = "UPDATE #__users SET username = " . $db->Quote($username_clean).
               " WHERE userid = " . $conflict_id ;
               $db->Execute($query);

               // create lookup table entry
               $query = "DELETE FROM #__jfusion_user_lookup ".
               "WHERE juser_id = " . $conflict_id ;
               $db->Execute($query);

               $query = "INSERT INTO #__jfusion_user_lookup ".
               "(juser_id, plugin_user_id, plugin_username, plugin_name) ".
               "VALUES (" . $conflict_id . ",$userid,".$db->Quote($plugin_username).",".$db->Quote($jname).")";
               $db->Execute($query);
               

           }
           
           

        }
        
        

        //make sure the username is at least 3 characters long
        while (strlen($username_clean) < 3) {
            $username_clean .= '_';
        }
        

        // make sure the username is unique
        $db->setQuery("SELECT id FROM #__users WHERE username=".$db->Quote($username_clean));
        while ($db->loadResult()) {
            $username_clean .= '_';
            $db->setQuery("SELECT id FROM #__users WHERE username=".$db->Quote($username_clean));
        }

        $instance->set('name'         , $username );
        $instance->set('username'     , $username_clean );
        $instance->set('password'     , $password );
        $instance->set('email'        , $email );
        $instance->set('usertype'     , $usertype );
        $instance->set('gid'          , $gid );
        $instance->set('registerDate' , date("Y:m:d") );
        $instance->set('block'        , 0 );
        $instance->set('lastvisitDate', '0000-00-00 00:00:00');
        $instance->set('sendEmail '   , 1 );

        // save the user
        if (!$instance->save(false)) {
        
           if ($instance->getError() == 'WARNREG_EMAIL_INUSE') {

           }
        
            JError::raiseWarning(500, $instance->getError() . 'plugin_username:' . $plugin_username . 'joomla_username:'. $username_clean . ' email:' . $email);
            return false;
        }
        
        // create lookup table entry

        $query = "DELETE FROM #__jfusion_user_lookup ".
            "WHERE plugin_user_id = ".$userid." AND plugin_name = ".$db->Quote($jname);
        $db->Execute($query);
        
        $query = "INSERT INTO #__jfusion_user_lookup ".
            "(juser_id, plugin_user_id, plugin_username, plugin_name) ".
            "VALUES (".$instance->get('id').",$userid,".$db->Quote($plugin_username).",".$db->Quote($jname).")";
        $db->Execute($query);
        
        return true;
    }

    function deleteJoomlaUsername($jname, $username) {

        //get the database ready
        $db = & JFactory::getDBO();

        $query = "SELECT juser_id FROM #__jfusion_user_lookup ".
            "WHERE plugin_username=".$db->Quote($username).
            " AND plugin_name=".$db->Quote($jname);
        $db->setQuery($query );
        $userid = $db->loadResult();

        if($userid) {
            //this user was created by JFusion and we need to delete them from the joomla user and jfusion lookup table
            $user =& JUser::getInstance($userid);
            $user->delete();
            $db->Execute('DELETE FROM #__jfusion_user_lookup WHERE juser_id='.$userid.
                ' AND plugin_name='.$db->Quote($jname));
        } else {
            //this user was NOT create by JFusion. Therefore we need to delete it in the Joomla user table only

            $query = "SELECT id from #__users WHERE username = '" . $username . "'";
            $db->setQuery($query);
            $userid = $db->loadResult();
            if ($userid) {
                //delete it from the Joomla usertable
                $user =& JUser::getInstance($userid);
                $user->delete();
            } else {
                //could not find user and return an error
                JError::raiseWarning(0, JText::_('ERROR_DELETE') . $username);
            }
        }
    }

    function joomlaUsername($username) {

        //define which characters have to be replaced
        $trans = array('&amp;' => '_', '&#123;' => '_', '&#124;' => '_', '&#37;' => '_' , '&#39;' => '_' , '&#40;' => '_' , '&#43;' => '_' , '&#45;' => '_' , '&#41;' => '_', '&#125;' => '_', '&quot;' => '_', '&#039;' => '_', '&lt;' => '_', '&gt;' => '_', '<' => '_', '>' => '_', '"' => '_', "'" => '_', '%' => '_', ';' => '_', '(' => '_', ')' => '_', '&' => '_', '+' => '_', '-' => '_');

        //check to see if a single or multiple usernames were passed on
        if (is_array($username)) {

            //remove forbidden characters for each individual username
            foreach ($username as $key => $value) {

                $key_esc =  strtr( $key, $trans);
                $username_esc[$key_esc] = $value;
                $key_esc = '';
            }

            return $username_esc;
        } else {
            //remove forbidden characters for the username
            $username_esc = strtr( $username, $trans);
            return $username_esc;
        }
    }
    
    function updateLookup($jname, $syncarray) {

        $forum = ForumFactory::getForum($jname);
        //get the database ready
        $db = & JFactory::getDBO();

        foreach ($syncarray as $key => $value) {

            //see if the entry in the lookup table already exist

            $db->setQuery("SELECT id FROM #__jfusion_user_lookup WHERE plugin_username=".$db->Quote($key));
            if (!$db->loadResult()) {
                //get the forum userinfo
                $userinfo = $forum->getUser($key);

                //get the joomla userinfo
                $joomla_name = AbstractForum::joomlaUsername($key);
                $db->setQuery("SELECT id FROM #__users WHERE username=".$db->Quote($joomla_name));
                $joomlaid = $db->loadResult();

                $query = "INSERT INTO #__jfusion_user_lookup
                    (juser_id, plugin_user_id, plugin_username, plugin_name)
                    VALUES (".$joomlaid.",$userinfo->userid,".$db->Quote($key).",".$db->Quote($jname).")";
                $db->Execute($query);

                //empty the variable ahead of the next check
                $userinfo = '';
                $joomlaid = '';
            }
        }
    }

    function getAvatar($userid) {
        return 0;
    }
    
    function getPrivateMessageCounts($joomlaUserId) {
        return 0;
    }
    
    function getPrivateMessageURL() {
        return '';
    }
    
    function getViewNewMessagesURL() {
        return '';
    }
    
    function getForumList() {
        // default implementation; return an empty array
        // must be implemented in the plugin classes where an object list 
        // with objects containing at least two members named id and name,
        // id for the forum id and name for the forum name. 
        return array();
    }
    
    function lookupUsername($jname, $username) {
        //get database object
        $db =& JFactory::getDBO();
        
        $db->setQuery("SELECT juser_id, plugin_user_id, plugin_username FROM #__jfusion_user_lookup AS jul ".
            "JOIN #__users AS u ON u.id = jul.juser_id ".
            "WHERE jul.plugin_username=".$db->Quote($username).
            " AND jul.plugin_name=".$db->Quote($jname));
        $result = $db->loadObject();
        
        return $result;
    }
    
    function updateUserDetails($userid, $userinfo) {
        //generate the Joomla password
        jimport('joomla.user.helper');
        $password_joomla =  JUserHelper::getCryptedPassword ($userinfo->password_clear);

        //get database object
        $db =& JFactory::getDBO();

        $query = 'UPDATE #__users SET block=' . $userinfo->block . ' , password = ' . $db->Quote($password_joomla) . ' WHERE id = '.  $userid;
        $db->setQuery($query );
        $db->query();

    }

    function lookupUserId($jname, $userid) {
        //get database object
        $db =& JFactory::getDBO();
        
        $db->setQuery("SELECT juser_id, plugin_user_id, plugin_username FROM #__jfusion_user_lookup AS jul ".
            "JOIN #__users AS u ON u.id = jul.juser_id ".
            "WHERE jul.juser_id=".$userid.
            " AND jul.plugin_name=".$db->Quote($jname));
        $result = $db->loadObject();
        
        return $result;
    }

	function createPassword($length) {
		$chars = "1234567890abcdefghijkmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$i = 0;
		$password = "";
		while ($i <= $length) {
			$password .= $chars{mt_rand(0,strlen($chars))};
			$i++;
		}
		return $password;
	}

    function filterUsername($username) {
        // default implementation
        return $username;
    }
}
