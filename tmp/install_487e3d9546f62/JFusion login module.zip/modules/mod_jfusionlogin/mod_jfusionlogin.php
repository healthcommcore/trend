<?php
/**
* @version		$Id: mod_login.php 7692 2007-06-08 20:41:29Z tcp $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2007 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once(dirname(__FILE__).DS.'helper.php');
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');

$user =& JFactory::getUser();
$params->def('greeting', 1);
$type 	= modjfusionLoginHelper::getType();
$return	= modjfusionLoginHelper::getReturnURL($params, $type);

//Get the forum integration object
$jname = AbstractForum::getJname();

if ($jname) {
    $forum = ForumFactory::getForum($jname);
    $url_lostpass = $forum->getLostPasswordURL();
    $url_lostuser = $forum->getLostUsernameURL();
    $url_register = $forum->getRegistrationURL();

    $forumlookup = AbstractForum::lookupUserId($jname, $user->get('id'));

    if ($forumlookup) {
        $forumid = $forumlookup->plugin_user_id;

        if ($params->get('avatar')) {
            // retrieve avatar
            $avatar = $forum->getAvatar($forumid);
        }
        if ($params->get('pmcount')) {
            $pmcount = $forum->getPrivateMessageCounts($forumid);
            $url_pm = $forum->getPrivateMessageURL();
        }
        if ($params->get('viewnewmessages')) {
            $url_viewnewmessages = $forum->getViewNewMessagesURL();
        }
    }
} else {
    //use the Joomla default urls
    $url_lostpass = JRoute::_('index.php?option=com_user&view=reset' );
    $url_lostuser = JRoute::_('index.php?option=com_user&view=remind' );
    $url_register = JRoute::_('index.php?option=com_user&task=register' );
}

require(JModuleHelper::getLayoutPath('mod_jfusionlogin'));

