<?php
/**
 * @version		$Id: joomla.php 9437 2007-11-25 22:11:40Z eddieajau $
 * @package		Joomla
 * @subpackage	JFramework
 * @copyright	Copyright (C) 2005 - 2007 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */


// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport('joomla.plugin.plugin');
require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');


/**
 * Joomla User plugin
 *
 * @author		Johan Janssens  <johan.janssens@joomla.org>
 * @package		Joomla
 * @subpackage	JFramework
 * @since 		1.5
 */
class plgUserJfusion extends JPlugin
{
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @param 	object $subject The object to observe
     * @param 	array  $config  An array that holds the plugin configuration
     * @since 1.5
     */
    function plgUserJfusion(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }
    
    /**
     * Remove all sessions for the user name
     *
     * Method is called after user data is deleted from the database
     *
     * @param 	array	  	holds the user data
     * @param	boolean		true if user was succesfully stored in the database
     * @param	string		message
     */
    function onAfterDeleteUser($user, $succes, $msg)
    {
        if (!$succes) {
            return false;
        }

        $db =& JFactory::getDBO();
        $db->setQuery('DELETE FROM #__session WHERE userid = '.$db->Quote($user['id']));
        $db->Query();
        
        return true;
    }

    /**
     * This method should handle any login logic and report back to the subject
     *
     * @access	public
     * @param   array   holds the user data
     * @param 	array   array holding options (remember, autoregister, group)
     * @return	boolean	True on success
     * @since	1.5
     */
    function onLoginUser($user, $options = array())
    {
        jimport('joomla.user.helper');
        require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');


        //initalise the Joomla database object
        $db =& JFactory::getDBO();

        //get main params
        $params = AbstractForum::getMainSettings();

        // Get an ACL object
        $acl =& JFactory::getACL();

        /*
         * First create the JUser object
         */

        //check to see if a JFusion plugin is enabled
        $jname = AbstractForum::getJname();
        if ($jname) {
            $forum = ForumFactory::getForum($jname);

            //generate the filtered integration username
            $plugin_username = $forum->filterUsername($user['username']);
        
            //If find out if the user has already exists in the Joomla database
            $userLookup = AbstractForum::lookupUsername($jname, $plugin_username);
            if ($userLookup) {
                $userid = $userLookup->juser_id;
                
                //update the joomla user details based on the forum user info
                $userinfo = $forum->getUser($userLookup->plugin_username);
                if ($userinfo) {
                $userinfo->password_clear = $user['password'];
                AbstractForum::updateUserDetails($userid, $userinfo);
                }
                
            } else {
            
                if (!$params->get('mirror_users')) {
                    $query = "SELECT id FROM #__users WHERE username='".$user['username']."'";
	                $db->setQuery($query);
	                $userid = $db->loadResult();
	            }
            }
            
            if ($userid) {
                //no need to create a new user object, just use the one stored.
                $instance =& JUser::getInstance($userid);
                //use the usergroup from the Joomla user table
                $grp = $acl->getAroGroup($instance->get('id'));
            } else {
                //find out if we should create a permanent entry in the Joomla database
                if ($params->get('mirror_users')) {
                    //yes we should create one
                    // baltie - fixed the code to support filtered usernames..
                    // should probably have a contigency if $userinfo is empty
                    $username_clean = $forum->filterUsername($user['username']);
                    $userinfo =& $forum->getUser($username_clean);
                    $usertype = $params->get('joomla_usergroup');
                    $query = "SELECT id FROM #__core_acl_aro_groups WHERE name = '" . $usertype . "'";
                    $db->setQuery($query);
                    $gid = $db->loadResult();
                    
                   //generate the Joomla password
                   jimport('joomla.user.helper');
                   $password_joomla =  JUserHelper::getCryptedPassword ($user['password']);


                    if (!AbstractForum::createJoomlaUsername($jname, 
                                                             $userinfo->userid, 
                                                             $user['username'], 
                                                             $userinfo->email, 
                                                             $password_joomla,
                                                             $usertype, 
                                                             $gid, 
                                                             $params,
                                                             '1')) {
                        // adaption of the fix provided by plamendp
                        return false;
                    }

                    //load the user object for the newly created uer
                    $userLookup = AbstractForum::lookupUsername($jname, $user['username']);
                    if ($userLookup) {
                        $userid = $userLookup->juser_id;
                    } else {
	                    $query = "SELECT id FROM #__users WHERE username=".$db->Quote($user['username']);
	                    $db->setQuery($query);
	                    $userid = $db->loadResult();
                    }
                    $instance =& JUser::getInstance($userid);
                    $grp = $acl->getAroGroup($instance->get('id'));
                } else {
                    //no just setup a user object but do not save it
                    $username_clean = $forum->filterUsername($user['username']);
                    $userinfo =& $forum->getUser($username_clean);
                    $instance = new JUser();
                    $instance->set('id'			, $userinfo->userid );
                    $instance->set('name'			, $userinfo->name );
                    $instance->set('username'		, $userinfo->username );
                    $instance->set('password'	, $userinfo->password );
                    $instance->set('email'			, $userinfo->email );
                    $instance->set('tmp_user', true );
                    
                    //we still need to create an entry in the user lookup table in order for the login module to work
                    $query = "DELETE FROM #__jfusion_user_lookup ".
                    "WHERE juser_id = " . $userinfo->userid ;
                    $db->Execute($query);

                    $query = "INSERT INTO #__jfusion_user_lookup ".
                    "(juser_id, plugin_user_id, plugin_username, plugin_name) ".
                    "VALUES (" . $userinfo->userid . "," .$userinfo->userid .",".$db->Quote($userinfo->username).",".$db->Quote($jname).")";
                    $db->Execute($query);
                    


                    $usertype = $params->get('joomla_usergroup');
                    $query = "SELECT id FROM #__core_acl_aro_groups WHERE name = '" . $usertype . "'";
                    $db->setQuery($query);
                    $gid = $db->loadResult();
                    $instance->set('gid',$gid);
                    $instance->set('usertype' , $usertype );
                    $grp = new JObject;
                    $grp->set('name', $usertype);
                }
            }
        } else {
            //use the Joomla default JUser instance, as JFusion is not configured
            $instance =& $this->_getUser($user, $options);
            //use the usergroup from the Joomla user table
            $grp = $acl->getAroGroup($instance->get('id'));
        }



        // If the user is blocked, redirect with an error
        if ($instance->get('block') == 1  ) {
            JError::raiseWarning('SOME_ERROR_CODE', 'This username has been block access to this site. Please contact the site administrator for more details.');
            return false;
        }


        /*
         * Now user and usergroup details are known the user plugin is the same for JFusion and Joomla users
         */

        //Authorise the user based on the group information
        if (!isset($options['group'])) {
            $options['group'] = 'USERS';
        }

        if (!$acl->is_group_child_of($grp->name, $options['group'])) {
            JError::raiseWarning('SOME_ERROR_CODE', 'You do not have access to this page! Your usergroup is:' . $grp->name . '. As a minimum you should be a member of:' . $options['group']);
            return false;
        }

        //Mark the user as logged in
        $instance->set('guest', 0);
        $instance->set('aid', 1);

        // Fudge Authors, Editors, Publishers and Super Administrators into the special access group
        if ($acl->is_group_child_of($grp->name, 'Registered') || 
            $acl->is_group_child_of($grp->name, 'Public Backend')) {
            
            $instance->set('aid', 2);
        }

        //Set the usertype based on the ACL group name
        $instance->set('usertype', $grp->name);

        // Register the needed session variables
        $session =& JFactory::getSession();
        $session->set('user', $instance);

        // Get the session object
        $table = & JTable::getInstance('session');
        $table->load($session->getId() );

        $table->guest 		= $instance->get('guest');
        $table->username 	= $instance->get('username');
        $table->userid 		= intval($instance->get('id'));
        $table->usertype 	= $instance->get('usertype');
        $table->gid 		= intval($instance->get('gid'));

        $table->update();

        // Hit the user last visit field
        $instance->setLastVisit();


        if ($params->get('mirror_users')) {

            if (!$instance->save()) {
                return JError::raiseWarning('SOME_ERROR_CODE', $instance->getError());
            }
        }

        //Create a forum cookie if JFusion is enabled
        if ($jname && $options['group'] != 'Public Backend') {
            $forum = ForumFactory::getForum($jname);
            $forum->createForumCookie($instance, $options, $session);
        }

        return true;
    }


    /**
     * This method should handle any logout logic and report back to the subject
     *
     * @access public
     * @param  array	holds the user data
     * @param 	array   array holding options (client, ...)
     * @return object   True on success
     * @since 1.5
     */
    function onLogoutUser($user, $options = array())
    {
        require_once(JPATH_ADMINISTRATOR .'/components/com_jfusion/admin.forum_factory.php');
        // Remove the session from the session table
        $table = & JTable::getInstance('session');
        $table->destroy($user['id'], $options['clientid']);

        $my =& JFactory::getUser();
        if ($my->get('id') == $user['id']) {
            // Hit the user last visit field
            $my->setLastVisit();

            // Destroy the php session for this user
            $session =& JFactory::getSession();
            $session->destroy();
        }

        $jname = AbstractForum::getJname();
        if ($jname && $options['clientid'][0] != 1) {
            $forum = ForumFactory::getForum($jname);
            $forum->destroyForumCookie();
        }

        return true;
    }

    /**
     * This method will return a user object
     *
     * If options['autoregister'] is true, if the user doesn't exist yet he will be created
     *
     * @access	public
     * @param   array   holds the user data
     * @param 	array   array holding options (remember, autoregister, group)
     * @return	object	A JUser object
     * @since	1.5
     */
    function &_getUser($user, $options = array())
    {
        $instance = new JUser();
        if ($id = intval(JUserHelper::getUserId($user['username']))) {
            $instance->load($id);
            return $instance;
        }

        //TODO : move this out of the plugin
        jimport('joomla.application.component.helper');
        $config   = &JComponentHelper::getParams('com_users' );
        $usertype = $config->get('new_usertype', 'Registered' );

        $acl =& JFactory::getACL();

        $instance->set('id'			, 0 );
        $instance->set('name'			, $user['fullname'] );
        $instance->set('username'		, $user['username'] );
        $instance->set('password_clear'	, $user['password_clear'] );
        $instance->set('email'			, $user['email'] );
        // Result should contain an email (check)
        $instance->set('gid'			, $acl->get_group_id('', $usertype));
        $instance->set('usertype'		, $usertype );

        //If autoregister is set let's register the user
        $autoregister = isset($options['autoregister']) ? $options['autoregister'] :  $this->params->get('autoregister', 1);

        if ($autoregister) {
            if (!$instance->save()) {
                return JError::raiseWarning('SOME_ERROR_CODE', $instance->getError());
            }
        } else {
            // No existing user and autoregister off, this is a temporary user.
            $instance->set('tmp_user', true );
        }

        return $instance;
    }
    
    

    
    
    
    
    
}

